self.assetsManifest = {
  "version": "qMOd2eEo",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-BXz5RCSFBrg3KCDZD4lxgyWmw1YH6vUT0N/oIQdCKfA=",
      "url": "_framework/CsvHelper.5c97h8cn3b.wasm"
    },
    {
      "hash": "sha256-Jv9S5coLP28fMUd+sd72uOfd5e3pWx+IFMRNtR/lykc=",
      "url": "_framework/Markdig.earcieyyzk.wasm"
    },
    {
      "hash": "sha256-KTpcAntnKj0pFDA0DcR7ixkFqmXTt1WeC+oj3KH8Zak=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.5hc85pygog.wasm"
    },
    {
      "hash": "sha256-5SH4o0p9+W6gGlJHsIffeQxutuo1/Zun8XXwBgrXlaA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.z27pu83re9.wasm"
    },
    {
      "hash": "sha256-oYV2/nQUBqtFe8PClwbsYfyJ/4t7d8A4vrn2VdL/XAU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.dlao6dmfoi.wasm"
    },
    {
      "hash": "sha256-QVyVhYw7bge0cKN5IztsqU0A7WlPdUF7MXskKv2TFIU=",
      "url": "_framework/Microsoft.AspNetCore.Components.zf0yl6yt36.wasm"
    },
    {
      "hash": "sha256-1daKPZGFmrBRROviBW7wQvK7sLXV2zP9ksJqhNgsx+A=",
      "url": "_framework/Microsoft.CSharp.1tgbx7jxy5.wasm"
    },
    {
      "hash": "sha256-psbVubDTAyYOD2TxdTLuX+4sqAcVFdyYdgHWv76/QCo=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.a3v99ix2bo.wasm"
    },
    {
      "hash": "sha256-t2wYIKjvBzfjc2zZdhp0GB7OKd8MheqkFtcHw6Eoy9c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.t738dd5cwp.wasm"
    },
    {
      "hash": "sha256-Mh0KjNP+OaNB1dEGdCq/bjkBC5/l3fUFwlkyu9sUaS4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.mj3lcrovda.wasm"
    },
    {
      "hash": "sha256-cFMP8L8jC5mFz6dNf8XoV7oNfAq3C3rQb1EkT6fZsYw=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.oyvz0ktixn.wasm"
    },
    {
      "hash": "sha256-+OtEbqT6riah0uLFC4sYpZvGS471XM/fpI0JIkt9Jts=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.kh5t30zhgm.wasm"
    },
    {
      "hash": "sha256-t66tesvI8LCpPqOKergTwOkOJD3zMQvtdEJ9s4vA1r0=",
      "url": "_framework/Microsoft.Extensions.Configuration.tfl7drb7rn.wasm"
    },
    {
      "hash": "sha256-A0jsQmxpWAyEozp1abrIzzsChUC9vLxm0ajOi/B59sw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.d0ne8haze0.wasm"
    },
    {
      "hash": "sha256-1sHGtdLxvz2GQFO06Df+jiw4RZMO0IbJCWgulIW/9dg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.a0ig3z30jj.wasm"
    },
    {
      "hash": "sha256-6d2/U3xJnwy1H+9UhrQJncrTa5mMT3tTDojz74JbzS0=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.n4z9wqozkg.wasm"
    },
    {
      "hash": "sha256-CEOUa87WlYwsxsfFGNNEr/x+6ge6LXX90VIdLHeTWXM=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.owfiup0dnv.wasm"
    },
    {
      "hash": "sha256-iaHgw5jtVAvokkMQZZmvJTbvEYo3wUfQHiUHgxwSR10=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.z9h0z9kwp0.wasm"
    },
    {
      "hash": "sha256-pWMo7e6AQ3R/vHPyDHP/mcCTRhQq/iE93BnHyFiuplg=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.h9d2ce7zmv.wasm"
    },
    {
      "hash": "sha256-wlL/O8N4Yfu+RWei0pGvH0yPz6YtxU9e0zmbkdhGP/Q=",
      "url": "_framework/Microsoft.Extensions.Http.ahxn0x459d.wasm"
    },
    {
      "hash": "sha256-cs96uBaYPjoEkozv3q/E9rUD1Ta+ijfGbH2iWsTrqww=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.yg18a3my1h.wasm"
    },
    {
      "hash": "sha256-rzGK1DRDDNZhuTVzo2m6LzW1Vwu7EffTeZdKuwwcMuc=",
      "url": "_framework/Microsoft.Extensions.Logging.b9y9o55egd.wasm"
    },
    {
      "hash": "sha256-9TMQls0B1XCFgVyWBcR/his4nSBUitXQBe2wyvBpju4=",
      "url": "_framework/Microsoft.Extensions.Options.3am5s0nz96.wasm"
    },
    {
      "hash": "sha256-UZyr9v9k89SEpuaMUGVwf0E9tSJBl0T7PHjWL9ZC6QE=",
      "url": "_framework/Microsoft.Extensions.Primitives.vkc0saelad.wasm"
    },
    {
      "hash": "sha256-Qn+nkd7OAgt+Wej3pFHojex7JXfMxa0jFhGlIvtI/Hw=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ycvepgv0z3.wasm"
    },
    {
      "hash": "sha256-Bxr/c7kNmD5H2rdVhLo7UxMiagdgh/VqWz4i/qYVpks=",
      "url": "_framework/Microsoft.JSInterop.vqca32xuxa.wasm"
    },
    {
      "hash": "sha256-fML+lmz+/rb8QjQOJxnpSZo0Xy0HpPwuhHSk7GYl1Aw=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.k4mmk8vayy.wasm"
    },
    {
      "hash": "sha256-4pzxa7aKLbYo3Wth3MOBkJqOSqx9jplUYQNU+/AVvDo=",
      "url": "_framework/MtgCsvHelper.iw5o94j0t1.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-92hYjPt6HQIX8HGRPk/QYW/58wE14qiBy8Q/Uuu9wGY=",
      "url": "_framework/Serilog.Extensions.Logging.jlvwho3ndn.wasm"
    },
    {
      "hash": "sha256-ZuPOCipC0T7x7hJNpiFLCGc/zMcJbLOSfAy5oehlFNE=",
      "url": "_framework/Serilog.Settings.Configuration.urndn343zs.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-NWMsCoF+R7Mv7Z6BEPXyMs0jCnZVOwXiBCAixBiNJuQ=",
      "url": "_framework/Serilog.Sinks.File.5g37eutqen.wasm"
    },
    {
      "hash": "sha256-Mixvd0zO4zdG/rrobpKpFBVxZ/ctp65CFrXTv2c5s2o=",
      "url": "_framework/Serilog.ysqu1a8zas.wasm"
    },
    {
      "hash": "sha256-CtgiHqt0232FbclcHNQScIfbuUnODhSH/5DtS6cd/kY=",
      "url": "_framework/System.6wfu8d6vsg.wasm"
    },
    {
      "hash": "sha256-olEO+2KHaTa3A5hI2DihQALFmGdWfdB37+OB+NWLV8A=",
      "url": "_framework/System.Collections.Concurrent.yrvm01gn62.wasm"
    },
    {
      "hash": "sha256-qmywUKIEIok1HR/hQVmstU4W5LNO7517SNSL42elCfc=",
      "url": "_framework/System.Collections.Immutable.6x8me28sdc.wasm"
    },
    {
      "hash": "sha256-fDa1owDxjs1JXRI6/IdEq3kvtQih7NiA5r+CpDlz7vg=",
      "url": "_framework/System.Collections.NonGeneric.g3k793ojdp.wasm"
    },
    {
      "hash": "sha256-DjvI3qMCSWasNy5xcRGlI/Eqg0eJB/us2eG0JNsjm/8=",
      "url": "_framework/System.Collections.Specialized.qmgbodzs8u.wasm"
    },
    {
      "hash": "sha256-DFITTxzRYWAUyZQDlVk1u9ebgD6lzTzZYbgdM8WE4Gc=",
      "url": "_framework/System.Collections.cshkzqtlfc.wasm"
    },
    {
      "hash": "sha256-xxLJC1GePE3L7yarJ+iIrU5sn92Ez1OdX479Sr+9Ph4=",
      "url": "_framework/System.ComponentModel.Primitives.pwa0603fef.wasm"
    },
    {
      "hash": "sha256-XJxNsEQlv61IiO1gv7lGe9akgL6jujoS9hfMf/c+IL0=",
      "url": "_framework/System.ComponentModel.TypeConverter.skzlxdqxoc.wasm"
    },
    {
      "hash": "sha256-15FB/iV4iHNMop+RjdwMjEunYkBFKV51WHyOKTnuHko=",
      "url": "_framework/System.ComponentModel.bnxu07l7tl.wasm"
    },
    {
      "hash": "sha256-HdqPccXnNRzabNhPSgxXyWoKvhuGXAmSeCzqk70fa/E=",
      "url": "_framework/System.Console.jkstggyqgt.wasm"
    },
    {
      "hash": "sha256-yvNd0TJeITMeuyd0AXpqKn7S+6Wqnr9MmJ6muI1ZUTY=",
      "url": "_framework/System.Data.Common.iy762xep8e.wasm"
    },
    {
      "hash": "sha256-nSK+f4KCWx1hSty1Qah/C9EnUwwP0F/a7kUprglOMxo=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.p5d8ib9h4e.wasm"
    },
    {
      "hash": "sha256-WR++fUoBjrFeJ5XNHe2PVLzPvzToS2rWga7CjeMEkrI=",
      "url": "_framework/System.Diagnostics.TraceSource.5tsyld1r5z.wasm"
    },
    {
      "hash": "sha256-0jvFTnPnask9c/CMwYMCT4JffxAAiHH79W5+mJKvzHk=",
      "url": "_framework/System.Drawing.Primitives.yss0ev0g4f.wasm"
    },
    {
      "hash": "sha256-Yz78yET3MHyey2N+Ftc5V9VNNK4BZynBpkN6l6UI5Uo=",
      "url": "_framework/System.Drawing.xb7qqkny3k.wasm"
    },
    {
      "hash": "sha256-POBRVx22VpjjVrhkPk5A637pUdFjq7ILLJeluH0El+0=",
      "url": "_framework/System.IO.FileSystem.Watcher.suj9nniwax.wasm"
    },
    {
      "hash": "sha256-BJkIz/RYV/YH2l/k9DSQCyEGEO++ICCJf8CcopkhmLQ=",
      "url": "_framework/System.IO.MemoryMappedFiles.0hiqt3tf8r.wasm"
    },
    {
      "hash": "sha256-ry9tC37SIIrYHgYXnNy3IWtkNjhvU9Dx8hpnH28PG/8=",
      "url": "_framework/System.IO.Pipelines.579zrviz2a.wasm"
    },
    {
      "hash": "sha256-RBu3q9P0IQfzSvqT7ofDyrjSXY3lV71TZQXpJKC/Xvc=",
      "url": "_framework/System.Linq.8hh1i1meph.wasm"
    },
    {
      "hash": "sha256-UVxwu9sduruRCXu4VMigjzTDocpG1xXwlPtFwLhe8oM=",
      "url": "_framework/System.Linq.Expressions.zb4jrrw7df.wasm"
    },
    {
      "hash": "sha256-KO+r72wA9BmKI/74HFzteodtJ9iUqmfMz2Fys8YDiQg=",
      "url": "_framework/System.Memory.cfnxohq6fh.wasm"
    },
    {
      "hash": "sha256-F8FWSmqG6aQKNgQMUJb5Cy2rp3HnlQvX8WV+8PnhjCA=",
      "url": "_framework/System.Net.Http.3tg43kqxs2.wasm"
    },
    {
      "hash": "sha256-wWpfnIM/nu2A/r8juk79SuMIP03ovoEdDp8Z2K5pJRY=",
      "url": "_framework/System.Net.Primitives.fodk77z0pr.wasm"
    },
    {
      "hash": "sha256-Gk4u9b/xtmZdZDFdLF7WAjCRkKEAIULbQtaHf+4naS8=",
      "url": "_framework/System.ObjectModel.y2nhfgx0il.wasm"
    },
    {
      "hash": "sha256-4qXIZW6znqfsOpCsmIo2AsVwriLfklHKLvnKPl3nR5Y=",
      "url": "_framework/System.Private.CoreLib.mi0m2vxmw8.wasm"
    },
    {
      "hash": "sha256-wQ30/hOI6SjQV0J03gIvhVkcMuqQMMRC+I2/mdHlbNY=",
      "url": "_framework/System.Private.Uri.bpf7zlvhtd.wasm"
    },
    {
      "hash": "sha256-3UEm2/qIiHQGTTwpOvLxfjRQpW8WVHvuSrcpNWWzkiA=",
      "url": "_framework/System.Private.Xml.564frpszh1.wasm"
    },
    {
      "hash": "sha256-h4DRisecwJBqD/ivvz4sJzZL6kEHcru1QUPyLlbGGiM=",
      "url": "_framework/System.Reflection.Metadata.3xax7ho006.wasm"
    },
    {
      "hash": "sha256-28LAmo36JqJstR2WUknR3fV4/lPxX7bg0YJ2i3OKmFc=",
      "url": "_framework/System.Runtime.3ilged9hev.wasm"
    },
    {
      "hash": "sha256-atY8hb/rIHUbWtvrSeB+okS9Y/9HShtmBX/hBopJ6Y0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.e3rxrh7ufy.wasm"
    },
    {
      "hash": "sha256-nFs4f/Bi+Js5Kw4wGkqiUvn2ZjmcdKnw7oedFxNcIEw=",
      "url": "_framework/System.Runtime.InteropServices.s00e4cnjr5.wasm"
    },
    {
      "hash": "sha256-rQf2fbQBXtgLO7d1ms0Z3ALfeNUxaJ9n3eJBNENZ7II=",
      "url": "_framework/System.Runtime.Numerics.leqsftxekk.wasm"
    },
    {
      "hash": "sha256-qwVKDgV0N1oR9TI1+51IDssJbfwzDEo09YmiS03a4rI=",
      "url": "_framework/System.Runtime.Serialization.Formatters.juyhrkrzvn.wasm"
    },
    {
      "hash": "sha256-Aq4t+Sh/DMPgbKzNDBxwmCdlFz06NI+bQPog56Kz1jo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.a1hjp7kg8c.wasm"
    },
    {
      "hash": "sha256-ZF+5S7NL2ReLV4kViFIoDyi/stXdzEQKmnUYarvwjUY=",
      "url": "_framework/System.Security.Cryptography.kislxvwafk.wasm"
    },
    {
      "hash": "sha256-PJDSzE40mM2ZsS/NqozQbExsNmHZIjweQK7L6qf7Dsc=",
      "url": "_framework/System.Text.Encoding.Extensions.c23lt0nfz5.wasm"
    },
    {
      "hash": "sha256-plh5udSFWQwQZNkdwzwDt3uXDVMvV6mpUcOpVOVuers=",
      "url": "_framework/System.Text.Encodings.Web.eeu7jcmznm.wasm"
    },
    {
      "hash": "sha256-yvgjP9gfdsNoeyKXyYpzNQfb8m7FSyLu9splNocbz28=",
      "url": "_framework/System.Text.Json.6hmwn6zhes.wasm"
    },
    {
      "hash": "sha256-wEGcGhPOi+RiouAxsZ5S3zBuHCBrEyocF8vr6VbmblY=",
      "url": "_framework/System.Text.RegularExpressions.s10yxvnw2i.wasm"
    },
    {
      "hash": "sha256-Blm7YfrGb/phOBuVFiYwpoz4CRO+hrTE3Q2+z57AQdc=",
      "url": "_framework/System.Threading.mwfi8w7pjj.wasm"
    },
    {
      "hash": "sha256-t1QusLL94utW2ThaKWXNcwPhXzdISkLpkrYJn8hoJpQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-gvHfnndfEu1tRf0rFb5988rWq7ITIotOaE8+AMbKYbc=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-r+0JJkNRopcjCdvu4kNlzuZR2a6pE+/WCMG/1eFdRCI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-rUaj/T0Guvy8fSq9FCxdeZ/xO4pk+qrbb1CjONXNqos=",
      "url": "_framework/dotnet.native.b6fudx4mdm.js"
    },
    {
      "hash": "sha256-77nesVspmpjkp2frwQNcSlmixYdRni+ZAnHVCcFEn+o=",
      "url": "_framework/dotnet.native.x42hp2a2cc.wasm"
    },
    {
      "hash": "sha256-1lGQC47gePi9fLGPDXRbA//I7x1RZ2FrSoAwS/Piloo=",
      "url": "_framework/dotnet.runtime.26xtx0erx2.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-aVU+wNshPgeOY1aodby6imEWCzjkotNfFAFqcae9Pwk=",
      "url": "_framework/netstandard.fywr7h45io.wasm"
    },
    {
      "hash": "sha256-sB6U1B8Ayhd0JbpcytwEV733h6l928gnvMSWSxJA0Yk=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
