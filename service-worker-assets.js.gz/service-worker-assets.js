self.assetsManifest = {
  "version": "bj90hAPX",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-Iqaxw48vzJ090QjTKIZ+Ol3hvIpRr19gmq0d1MnjgS8=",
      "url": "_framework/Microsoft.CSharp.qio8szn4eq.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-Z/USY39C6YS5t3ZLLpQPSb54WXg4cw4Db6zlwc3kVOk=",
      "url": "_framework/MtgCsvHelper.5p9uyrp1i6.wasm"
    },
    {
      "hash": "sha256-tpuLVIQLebcj/HRdO/OZK2+jS+IQ218MHqBdia7RjNc=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.yl65nl0gfm.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-IilH9xUSfCv0ovcxZ9JX2p6BKnBsYgo5dmDW7WQNKqE=",
      "url": "_framework/Serilog.mutfikrzmn.wasm"
    },
    {
      "hash": "sha256-sUe1SZNtXX5j5ycVZolnLBvnxmZWgSJsG1+Wh/s2hmA=",
      "url": "_framework/System.Collections.Concurrent.5but16llr1.wasm"
    },
    {
      "hash": "sha256-Kc6CKslwhrJyStGNprOrTeBzpNGD3gCYafroomzOb7U=",
      "url": "_framework/System.Collections.Immutable.9oo91ysv9w.wasm"
    },
    {
      "hash": "sha256-vuRCyEasAkSePbt4nE5dcLmrA+us/ZHnQ0zU15Myg2s=",
      "url": "_framework/System.Collections.NonGeneric.qaw7gbmsus.wasm"
    },
    {
      "hash": "sha256-o4vWByO6qTipGVRcnQXAXQ2okk6surfqweRgoQxG7yU=",
      "url": "_framework/System.Collections.Specialized.xjxm5745n5.wasm"
    },
    {
      "hash": "sha256-Ao/z2kUPtI1qsE3VTelkHsqrhMggK/T0sYpRo3/HGLM=",
      "url": "_framework/System.Collections.mz0c3btpo2.wasm"
    },
    {
      "hash": "sha256-ILP/42wGN8ghgnGpgA5ZlIjxTU6UVSKjVk6sdUN0pPo=",
      "url": "_framework/System.ComponentModel.Annotations.0o0rzhp41t.wasm"
    },
    {
      "hash": "sha256-HvPQAxhx5tZ9Oqb6Yjf+Io2NY2B4Sxs4iJSLrjkVkZk=",
      "url": "_framework/System.ComponentModel.Primitives.qlpqjncyx2.wasm"
    },
    {
      "hash": "sha256-Km5Hm6TXUDAQg5MdZt5/O2WRKGgf79D3G6/C+yXVVyA=",
      "url": "_framework/System.ComponentModel.TypeConverter.yae7ak96wg.wasm"
    },
    {
      "hash": "sha256-6xI9OSPx+5XSOYkvAML5B/3GVYQPShxRZSyFvf/sJBA=",
      "url": "_framework/System.ComponentModel.pj195idgdy.wasm"
    },
    {
      "hash": "sha256-nPnOjsBLKp265giFSU8PhTJk58pDWz7hkAPgN3YZ2yg=",
      "url": "_framework/System.Console.cixfrpv71s.wasm"
    },
    {
      "hash": "sha256-VPnEBrZqSMEsrgURXpW5lFi9+zCKVYdQrUze5mKIrCw=",
      "url": "_framework/System.Data.Common.4093lhlpzg.wasm"
    },
    {
      "hash": "sha256-o/A4cIhblr7cPCF9FzQAs4zD3WbUeAQ6IpbYcQTGrvw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.hnddhy10tt.wasm"
    },
    {
      "hash": "sha256-ltA3chtI6JFRaPon4314D/LKkrIbpQfLIEjCxyrQVls=",
      "url": "_framework/System.Diagnostics.TraceSource.ydasd0sjq6.wasm"
    },
    {
      "hash": "sha256-NynWljsaS/G/dq658eLteDhcNsOXjVufgyAO+7XDMys=",
      "url": "_framework/System.Drawing.Primitives.tj8alqjuas.wasm"
    },
    {
      "hash": "sha256-cCr5omumEMXHinHEix8xZiTkT+EehqB59B9NCPae/as=",
      "url": "_framework/System.Drawing.wkm54058fc.wasm"
    },
    {
      "hash": "sha256-N2xHSDQOnWuK/inNYmh0ETQYHfwgzOgmpjzg8GvPztA=",
      "url": "_framework/System.IO.Compression.db7z4o6tq2.wasm"
    },
    {
      "hash": "sha256-s30lPdDBq8liUlIRUz3kERw6j7uRcpmENvuo3Qmf/fE=",
      "url": "_framework/System.IO.MemoryMappedFiles.jcz7jnm7xt.wasm"
    },
    {
      "hash": "sha256-amMIZxfjKiPxhYTQmJV3kp2p5j+sYYwNj2urD63o4Uo=",
      "url": "_framework/System.IO.Pipelines.2liefe2fsq.wasm"
    },
    {
      "hash": "sha256-/TdocynOG46RdI3s+Fo8BEn/dEEbL7VHYKTJwW9Brfc=",
      "url": "_framework/System.Linq.Expressions.nfxrmkwhzh.wasm"
    },
    {
      "hash": "sha256-zUw0c8NLWOeVJWdKwaqxrQr0l2YM+8nfCZ9JvqGGdUM=",
      "url": "_framework/System.Linq.ryhxyybk08.wasm"
    },
    {
      "hash": "sha256-LTM0IsIWN71OMBJuvmUL3B5ZLsjxA1lHd49avVxnLsg=",
      "url": "_framework/System.Memory.99yzn9mowj.wasm"
    },
    {
      "hash": "sha256-CA4PLRSonJsP1p5M3ZsC8HyddNE4bRRauPG5c5X7wGI=",
      "url": "_framework/System.Net.Http.kpfympvzbq.wasm"
    },
    {
      "hash": "sha256-TL+mtbgz28WCLrlcpkl8pUspipFGnvN+CFy9my4/XgA=",
      "url": "_framework/System.Net.Primitives.smog0w6q0n.wasm"
    },
    {
      "hash": "sha256-RcunCETdCxTjgdNl529wKoS2AMU4cuYpF+WL2WjY2mM=",
      "url": "_framework/System.ObjectModel.fbqa1g3es7.wasm"
    },
    {
      "hash": "sha256-mr+4TK6Dc0EndhCIgrl6cbepFtor47J+dy+8/0i9CO0=",
      "url": "_framework/System.Private.CoreLib.yy71x843a5.wasm"
    },
    {
      "hash": "sha256-/3cyphJwT/v4wrpIaff6jd1KBGupvhzWQ4d1SEO0vlw=",
      "url": "_framework/System.Private.Uri.tp2lf2hrk5.wasm"
    },
    {
      "hash": "sha256-XH+tfLzVeFBoPN6rAnszmH3mtVb853yzrM69dfoB5LE=",
      "url": "_framework/System.Private.Xml.0jrctzs4ii.wasm"
    },
    {
      "hash": "sha256-78HTnH1o86Sb0MsCEg/ZIWX9eQLdayg7Bm9yawXyZDo=",
      "url": "_framework/System.Reflection.Metadata.dxyxnaz8ze.wasm"
    },
    {
      "hash": "sha256-B0Rj/V6IB0igZFtRmzuGzPFbEYVeuApSYEHQdhjq8FQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.tbh1m6spat.wasm"
    },
    {
      "hash": "sha256-jItyf07BQiHuk/dd+9ol08DeM/6KIY+QMO598PW8c1A=",
      "url": "_framework/System.Runtime.InteropServices.sqnltnlnqh.wasm"
    },
    {
      "hash": "sha256-Nalxl3i/kKlSdkcVloPcxcXzvtpL2Dl628EhtvA8O1o=",
      "url": "_framework/System.Runtime.Numerics.da4ewvascu.wasm"
    },
    {
      "hash": "sha256-b3o+UHvHfNjAANdyc0h86DPUgS+v/aZRZGV/FnBmn88=",
      "url": "_framework/System.Runtime.Serialization.Formatters.h8idoo3haa.wasm"
    },
    {
      "hash": "sha256-nHRMiJppZyVuGnkhNbgu4H2b83cgg5WeWUE81Bgn7Eo=",
      "url": "_framework/System.Runtime.opwodrcqj1.wasm"
    },
    {
      "hash": "sha256-d2vGd6bZUod1W9XCu3Y9LaznqNaIGjTYMh55ZXM6JOU=",
      "url": "_framework/System.Security.Cryptography.febbh7rajm.wasm"
    },
    {
      "hash": "sha256-2Lziom56t9tYGK+UESWthrUXu8mM3hmHiOrOK16heyY=",
      "url": "_framework/System.Text.Encoding.Extensions.kllinayi9l.wasm"
    },
    {
      "hash": "sha256-HjCuzfCss3iLW0+pyYBzrh51+Bja5Wj8rM+o3rGnvJQ=",
      "url": "_framework/System.Text.Encodings.Web.edww83z5fq.wasm"
    },
    {
      "hash": "sha256-0k4/qxCteXSN3dRsDImn4rEEBYFj1dLL7Y2NyVSjAIQ=",
      "url": "_framework/System.Text.Json.yju6h8g459.wasm"
    },
    {
      "hash": "sha256-caOK7m4lfxJHKwTYT29Ti/E0iHXOjvF88e6lKEmq/KY=",
      "url": "_framework/System.Text.RegularExpressions.pu6v7ul6k7.wasm"
    },
    {
      "hash": "sha256-GBxxTNu4m28Hxirf7E5918tx2NZkPWuwFMutPT9oy/U=",
      "url": "_framework/System.Threading.8ofrcu1z5d.wasm"
    },
    {
      "hash": "sha256-QZM96Sbw2BYre4bcT9tJXUPU/9h0LdgAPwGMigVXC8g=",
      "url": "_framework/System.x4983syfn1.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-2XiJxu6wcPRRd1i2gmXi/OnJXOm9viEYfz8VpeKS/U8=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-okFXds2vNJzYKB55NsSY9eGKjd1yoW0B+oOqjV6Bwlk=",
      "url": "_framework/dotnet.native.at4snspvvz.js"
    },
    {
      "hash": "sha256-YbwYGW3be9VJzS2qsul6yZqpIH8FgkJFyo/lcVrac0k=",
      "url": "_framework/dotnet.native.x8auptapjw.wasm"
    },
    {
      "hash": "sha256-YyudibIWETMKrLb+nAZdJ+xDY7HY6BWf6s32UAdcvCU=",
      "url": "_framework/dotnet.runtime.r2kbxkuujc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-7Wq9wmhsl1ARpeYPqseTBigKG0L/TB4OeZrK9qdkh+w=",
      "url": "_framework/netstandard.p1rwiy4jsy.wasm"
    },
    {
      "hash": "sha256-XjQLW3PjWmsunh9pfPP9q8/OvK25ILaqPPgWZfJIb5w=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-DGxmhl7JjAalsv878IuZxkjMv2GHz8awkPd+8ts+IBo=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
