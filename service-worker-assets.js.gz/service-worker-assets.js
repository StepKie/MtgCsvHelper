self.assetsManifest = {
  "version": "V0M1OK4i",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-Ewgh2lrJzq/PuI+zHpT2bZx9E7YHtC1tuwdJgx5liBA=",
      "url": "_framework/Microsoft.CSharp.5i2hpyhhe6.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-wI9vW86RuVAfzkMH2kpDb6MCy4fvtqQmYXnvJ4IvG9c=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.8e03boqut1.wasm"
    },
    {
      "hash": "sha256-oIPN6jKUNVt+7vS+mW0auUIMYtQ+UrbpD5R9UC1wAYQ=",
      "url": "_framework/MtgCsvHelper.s5t0o6chbp.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-+/3A4lrXGyV1SI30Q8J0ONqqPp8Xhc5WJ4ABmiKHtpQ=",
      "url": "_framework/Serilog.v3jtg2iuay.wasm"
    },
    {
      "hash": "sha256-Jc5F2LpJIbQCm2IRcqkw63FExoLSSsspcYzaX9guH9M=",
      "url": "_framework/System.Collections.9znfz1cpqv.wasm"
    },
    {
      "hash": "sha256-3IovAHzPM50CiZd1dgebTFFhLtjacNyJbic9Wu0ffJI=",
      "url": "_framework/System.Collections.Concurrent.4m8dyzp7e0.wasm"
    },
    {
      "hash": "sha256-MxD2uYaI1K5OfjgPFh79e0kOoYs/6qs94dPNeKJcuVs=",
      "url": "_framework/System.Collections.Immutable.nr93odlcn1.wasm"
    },
    {
      "hash": "sha256-CLkHBNLjrrCdt4CwVKkGDiIR/TflQuWhI5wc4BQ4xF4=",
      "url": "_framework/System.Collections.NonGeneric.wqref175qe.wasm"
    },
    {
      "hash": "sha256-nuNOhYxmQqHypLeGMNAPyV+QAW6263UDxRy7sIfwdlc=",
      "url": "_framework/System.Collections.Specialized.e9xgoe8el9.wasm"
    },
    {
      "hash": "sha256-+tNuyDZwqiy9xZyweHauypGvvavFKtWz/nCwkmVlu8M=",
      "url": "_framework/System.ComponentModel.2lpuvkg07t.wasm"
    },
    {
      "hash": "sha256-dxbf/Zjoz5Nac3r4VTJn4Xj+oiJJLzRIRHVzJJ0Dqbc=",
      "url": "_framework/System.ComponentModel.Annotations.zpxb3lkkg8.wasm"
    },
    {
      "hash": "sha256-uzh6IpKg4dO1tV5PNW0TuDHCFzTZzF7CFi6sQUrsxeg=",
      "url": "_framework/System.ComponentModel.Primitives.hpf78ls5nc.wasm"
    },
    {
      "hash": "sha256-dRtbjE1BJ2PnXfJBH/UjpUkhnxdRabnBxFz+HKmKqa8=",
      "url": "_framework/System.ComponentModel.TypeConverter.r0bffs2umk.wasm"
    },
    {
      "hash": "sha256-BpzdJvk6LTlRpnK+QzXWcZm+o2BPU71c0xEWayd6GlQ=",
      "url": "_framework/System.Console.29k6g4hhmf.wasm"
    },
    {
      "hash": "sha256-xU/pETBHFVJGTGFdPXke/S4LzuMBG2cs6HyYttNC/p4=",
      "url": "_framework/System.Data.Common.h15dh1qgm0.wasm"
    },
    {
      "hash": "sha256-jnMzQu0np1BELHUvOY5pEIsrUz5kLplHpg0AULTwGyg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.estboohqu1.wasm"
    },
    {
      "hash": "sha256-FE9L5R20ySdrZ6H/T4LImcr9f56Whzq42Hh/v2tuUYk=",
      "url": "_framework/System.Diagnostics.TraceSource.8jydn6t5wu.wasm"
    },
    {
      "hash": "sha256-xErlddoBRNGn7QWOros7zHq30k8ykPx+iyETWFw9YC8=",
      "url": "_framework/System.Drawing.Primitives.csci0lvlwc.wasm"
    },
    {
      "hash": "sha256-U7pGfxw5D048q3pJfUynlq/AnwY9KVVAT8R8bFRgLpY=",
      "url": "_framework/System.Drawing.bquzof8wit.wasm"
    },
    {
      "hash": "sha256-cKulW63m+BeCViaHG9l/u8utzT3QWa6GHOwMrBfpa0k=",
      "url": "_framework/System.IO.Compression.ws4dbwl53n.wasm"
    },
    {
      "hash": "sha256-U0KxSA662hpOny53DBV0e/LYO7VESq+gbsmlV/ru4G4=",
      "url": "_framework/System.IO.MemoryMappedFiles.nnoqnrw2nn.wasm"
    },
    {
      "hash": "sha256-dvPcRkhB1z/H+8S377IuUqtsqStoKiwVfPoSbr5VZgk=",
      "url": "_framework/System.IO.Pipelines.qk2yz2gq10.wasm"
    },
    {
      "hash": "sha256-asIZLdM7PA+rsQyuglmMtieH6T/T/Zy5mxqGCawqMIw=",
      "url": "_framework/System.Linq.Expressions.6ks8rknfvu.wasm"
    },
    {
      "hash": "sha256-uWTxDbtfBHc86jr9AF7Gt5UpWpFT8XWr8elju55qpSc=",
      "url": "_framework/System.Linq.hyizqkf4a1.wasm"
    },
    {
      "hash": "sha256-SHcNGrGB6vgeKKHvuO6HRE3GxVFTwGmU9lrn3HwwNy4=",
      "url": "_framework/System.Memory.4512dq7frg.wasm"
    },
    {
      "hash": "sha256-k3kPspxM1DKna1zHCFwDq2XD/ItwjHtNC+Btbxob+gg=",
      "url": "_framework/System.Net.Http.dwaxdhkarw.wasm"
    },
    {
      "hash": "sha256-cm7Pi0b+fzuNir/OJS3ZiX0b8KNWOT6n48+s+3NxAUc=",
      "url": "_framework/System.Net.Primitives.m2b2xr23l5.wasm"
    },
    {
      "hash": "sha256-jmrbYQQzburfp9l3KVJwKPd3VhsitFS3oE1dTTTzncs=",
      "url": "_framework/System.ObjectModel.is7w2tt4ok.wasm"
    },
    {
      "hash": "sha256-j68a26qMlDz37cElEnu7Q6zFHIQ+cqqVwoL33amIkes=",
      "url": "_framework/System.Private.CoreLib.tdsvr9vo2k.wasm"
    },
    {
      "hash": "sha256-ZrstxgdmEQQaMcUbdpeg1qGSXpzXz6rYg/6YaF59s2Q=",
      "url": "_framework/System.Private.Uri.y1aaim8uza.wasm"
    },
    {
      "hash": "sha256-h+sfE69xn7TB0KBu7StPz5yDowIsaQvQrfawv630RAA=",
      "url": "_framework/System.Private.Xml.9w7aeom1hq.wasm"
    },
    {
      "hash": "sha256-clDBBOvT7OuLuPha7Q/dy1mHmE6kNLvaNS3a9C/v2PQ=",
      "url": "_framework/System.Reflection.Metadata.ir7pkqo0mu.wasm"
    },
    {
      "hash": "sha256-XUsjHNdIz31wW4bfYV5Emd4IzZROE5uAqaUxoK72P98=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.two9tufo66.wasm"
    },
    {
      "hash": "sha256-4+wUOmOeHb9VVnw/qPsZIogsoxc4Kl71cfZxlUaz19A=",
      "url": "_framework/System.Runtime.InteropServices.b6c1t3l6jq.wasm"
    },
    {
      "hash": "sha256-sQb0VO/r86dlqy2M64ZZ8vNb0QwzYCC46kqCQCNBlrA=",
      "url": "_framework/System.Runtime.Numerics.t9tq4v9sqg.wasm"
    },
    {
      "hash": "sha256-klGMzlDvoEaALUsb/t4jfCCfKuXK5WR9dz6cUly3MUc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.2byjiiml2w.wasm"
    },
    {
      "hash": "sha256-HzeugI41hHUhxlInRt6amS/KtX8ZY9FQDix8hZSas4Q=",
      "url": "_framework/System.Runtime.jjm8vxngsx.wasm"
    },
    {
      "hash": "sha256-tsG9lkx3Ecp3sC9D0wB9Zn1X77Kg6fmFF5TjscnqXnU=",
      "url": "_framework/System.Security.Cryptography.25oynzjseu.wasm"
    },
    {
      "hash": "sha256-Ujg2Kd4u+soD5hEId0WRpdVA7qPZRCJ41Y/DF/79CxY=",
      "url": "_framework/System.Text.Encoding.Extensions.qizm3e8m2k.wasm"
    },
    {
      "hash": "sha256-73DDC/unn9UrEfER8Jb7kjxrGR1+TrWpuhS2mVskys4=",
      "url": "_framework/System.Text.Encodings.Web.vcygnmhnwy.wasm"
    },
    {
      "hash": "sha256-KxXiXs/fwvjbKl7ifnYVSwrnTZICnOBUzU1LAvAtKYI=",
      "url": "_framework/System.Text.Json.t6q5fimuzo.wasm"
    },
    {
      "hash": "sha256-EwkWs+xarWeHpzS3E42D5antjz0seDBVu16HEawEu1s=",
      "url": "_framework/System.Text.RegularExpressions.1vxmisuqot.wasm"
    },
    {
      "hash": "sha256-Kj7tOZ6R1Z5JZdikq3WgIEysZUwhKLx2kwjW2xktX30=",
      "url": "_framework/System.Threading.e3fb1bfy8u.wasm"
    },
    {
      "hash": "sha256-Oi2ZVXkw2JmP+MBLYf56Z9QoZPjrC9vYuyU2cUrA7EM=",
      "url": "_framework/System.qf9o9thhcz.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-yDDN+ctNtCjd0OVs56T9DMOLyf9XHUMWayAygn+xiFE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-3hLNQ/BH33KJvp1G7ZTB7JYU9hwXNhAXkDltVTgOF4U=",
      "url": "_framework/dotnet.native.6n270py7oe.wasm"
    },
    {
      "hash": "sha256-3Iaqskuovjt35NoTH1Zqo2pTKwMzvuKQWQSr0Rqre4M=",
      "url": "_framework/dotnet.native.85mrmic3su.js"
    },
    {
      "hash": "sha256-muN076HgyOCoAaid7zD7a2/GN7aQ7tmK/BzdnKgw78g=",
      "url": "_framework/dotnet.runtime.azrfhwb804.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-0Bg2+Y+V9zZu9LXct6LL+rZz8yKPAY8peJ7dmAFRkhI=",
      "url": "_framework/netstandard.8eptnrz8r6.wasm"
    },
    {
      "hash": "sha256-OVdd3PpMznuWCRsm073NkDNne0opNWFEdQ0WdkVAF+Q=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+TWS5ty7CKU2ykydB9o6sLp/DGprCfkPqi36ggl9v24=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
