self.assetsManifest = {
  "version": "T8PpdiVC",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-BXz5RCSFBrg3KCDZD4lxgyWmw1YH6vUT0N/oIQdCKfA=",
      "url": "_framework/CsvHelper.5c97h8cn3b.wasm"
    },
    {
      "hash": "sha256-4NRl6Uv3KMSWq86K58aRc0myM/vF0kILqNdUqpOTXdw=",
      "url": "_framework/Markdig.8m8q17eux9.wasm"
    },
    {
      "hash": "sha256-dKgh5yuNECZH/1q+oIacdVmSy2YwGYKuhrNbrdoWMNo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.w1f1u6fc7v.wasm"
    },
    {
      "hash": "sha256-L4uFpRzIguJOO95kOcjVnolpvhgvwyXtoSZ+nI03uGs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.3nz7zuaghl.wasm"
    },
    {
      "hash": "sha256-xf6XKFsMf7bO/DMnunCG6ohXlszxTje/SwKj7pRD8tI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.v3b4wsadvq.wasm"
    },
    {
      "hash": "sha256-MPHJCaaqBkOk7OpADw4jfBOfRY/iDjy1Yzcb+PmLeco=",
      "url": "_framework/Microsoft.AspNetCore.Components.cpgh00uf4v.wasm"
    },
    {
      "hash": "sha256-57L34kSWKqEbHj1iJ6mR3m394hVTlSDq6kl8TMxpaac=",
      "url": "_framework/Microsoft.CSharp.jlahjsktkv.wasm"
    },
    {
      "hash": "sha256-2HKf0tyaZocKkK7AO/+J79vmNh6Bukv0DABg3Uc8Ejw=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.cfjygr068g.wasm"
    },
    {
      "hash": "sha256-pUZS9KRTtJM0+KM+GNhOfuUiPcEaIT9clJ4yr5KQ014=",
      "url": "_framework/Microsoft.Extensions.Configuration.5wexlehhxa.wasm"
    },
    {
      "hash": "sha256-DdoauGc+iidehKzTShs4VrucOXRkdR94sfB1KBNzcL8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.plgo47r3nw.wasm"
    },
    {
      "hash": "sha256-wLdgI1yICC7hhu4LaVJdYKEBU0oUft/XddFbPmzxoBE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.8yn03f5gvt.wasm"
    },
    {
      "hash": "sha256-aosgPyEoZ6K/KnqxYnRHU9TP9buJjJFVCEITl/wn+0c=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.qztr0h4aol.wasm"
    },
    {
      "hash": "sha256-IaJXi4GvkzKztT9qRt4SlpQKpKaFh9tu1641CDwqPhA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jbgtyhqqh7.wasm"
    },
    {
      "hash": "sha256-hUVwiIvOJVPsoy1MFq/9rljDduPn2WG/oh+JWDjmHu4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.zua27c4rm2.wasm"
    },
    {
      "hash": "sha256-jUfkp8Vqd/tdShyuGo2VC5pmHrSaYOV4V4pbGEQ2aVw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.tkiy5gl44a.wasm"
    },
    {
      "hash": "sha256-Y50HX3PQMJ4soEY3qF5l62/MIU7ySWSua6rOnJTS588=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.v9g0nhfssu.wasm"
    },
    {
      "hash": "sha256-po9BNhMukFMXJdfa5XW6bHmb0DHDvw5JKx7soMnSv7k=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.eix4luiuev.wasm"
    },
    {
      "hash": "sha256-TQ+9qUuilCpfMqwgJSC1vBLudpb7p3MPmBU6pshy97A=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.la1nd70oz7.wasm"
    },
    {
      "hash": "sha256-1HkbsCtHq2wCs8EGJQ8sj8WaqMYrDDQ1Gx49MElu+wU=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.g9o4u6z1mh.wasm"
    },
    {
      "hash": "sha256-mSTkUwaJW1rzV8XnxyTe2sR0d+be7DjzHDESqhb0y0I=",
      "url": "_framework/Microsoft.Extensions.Http.bvoe29ity8.wasm"
    },
    {
      "hash": "sha256-vTVCgsOm4WY6f4H0MOJ9K0YgJCxiLVZoCamsARSbIMg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5i3cpkp2v8.wasm"
    },
    {
      "hash": "sha256-JGUfilPT4uhjy7AW2qYCQ8qAvp/sx9slOxD5FUalXqE=",
      "url": "_framework/Microsoft.Extensions.Logging.whaspudibf.wasm"
    },
    {
      "hash": "sha256-OmtxjxQcJweFHYqv4XqbeYjkq2XIigf/ydNqiFSytcs=",
      "url": "_framework/Microsoft.Extensions.Options.y188ye2hky.wasm"
    },
    {
      "hash": "sha256-ZWW0ybvWUm8zyZSvyzzUEtIh/d6Xz7dhOo+u9W7i47M=",
      "url": "_framework/Microsoft.Extensions.Primitives.1lrnimddfw.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-WevtyYqrTiNm+7OBxHZqTPG4sUio1ev4KYQw0AGZk2Q=",
      "url": "_framework/Microsoft.JSInterop.h674qle9ql.wasm"
    },
    {
      "hash": "sha256-w0P4rUW7joQRne3Pt3PTkam5tWqD41nMm4x+EzEMO1Y=",
      "url": "_framework/MtgCsvHelper.30ssfyp445.wasm"
    },
    {
      "hash": "sha256-6eozAlAIAmkwc49D4FHtBcuVWvmX2CVwQnyGBhrsCZI=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.p8rwl9m5c9.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-7Ph4DpIYUm6II3daX+GzmBUn++wgpMabIVkhba2X9FE=",
      "url": "_framework/Serilog.4s67d7c21i.wasm"
    },
    {
      "hash": "sha256-VP3ipQ0Mgb9NgEMkH08GEup2of20grWfwfDR87CUSAo=",
      "url": "_framework/Serilog.Extensions.Logging.sq1iwxadv9.wasm"
    },
    {
      "hash": "sha256-F3KAlF5HjvkTXwbLVn9fiSxSPwdZrsU3wEdEI3nsBo4=",
      "url": "_framework/Serilog.Settings.Configuration.vqprv27ecs.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-3n/Wg+O5hU4wIsfJFdsPqLUaTmsUmZEbmudqycrn61o=",
      "url": "_framework/System.Collections.6mcs5nn4m9.wasm"
    },
    {
      "hash": "sha256-AbxEcx+BCzYXHWHfJyZIIOh5kOHOJtKC2ZgPjpZk5OY=",
      "url": "_framework/System.Collections.Concurrent.5j9vefdxy3.wasm"
    },
    {
      "hash": "sha256-N/DjFZ83lPtVykJUrVdqBg3lT5eJP5+U6SuIh8RvuAw=",
      "url": "_framework/System.Collections.Immutable.bfdp472fpd.wasm"
    },
    {
      "hash": "sha256-+FaP+oWdECgFdFZN34gq5L3tKHIuBOhQgYlrWRFWO0s=",
      "url": "_framework/System.Collections.NonGeneric.4prv1uecik.wasm"
    },
    {
      "hash": "sha256-ofabbGoXtQzraPK8uqEpxC7qctt6RkHfgTs+vvFXULA=",
      "url": "_framework/System.Collections.Specialized.jr0e6aivlq.wasm"
    },
    {
      "hash": "sha256-LbLhkJOBFyXPfDEPFeSMSWN1n5GGg+qZ4htIYRQYB80=",
      "url": "_framework/System.ComponentModel.3sa9zzkkg2.wasm"
    },
    {
      "hash": "sha256-hTNowvVMhwtI5C1GDwfa4DygTmNmo5vAr7EJLi/8a1o=",
      "url": "_framework/System.ComponentModel.Primitives.pv18guftm9.wasm"
    },
    {
      "hash": "sha256-6tpiQMmnzambX0Cx6nBMwKx84mJICOi5pf8FiSNsTkw=",
      "url": "_framework/System.ComponentModel.TypeConverter.25292s4l2s.wasm"
    },
    {
      "hash": "sha256-kMXIdVpZSBHH0gbWEe8/exaEhmhNio3qkr/5B5rrldg=",
      "url": "_framework/System.Console.43084hi8hl.wasm"
    },
    {
      "hash": "sha256-r7OQ0BZ+6LxEzvkJCyyaXbjPlqMu+RDopU1gmpU9/BQ=",
      "url": "_framework/System.Data.Common.j3rmh40hsl.wasm"
    },
    {
      "hash": "sha256-ZhGQIPs+51J9dewA2qJhe4S/X3xLF4lreeLS+XwVI1g=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.eyd7z3ij4m.wasm"
    },
    {
      "hash": "sha256-Xw5qTdDSl84+R8sQ9n2hQhOXiHn34D0lw6k3urWQkhQ=",
      "url": "_framework/System.Diagnostics.TraceSource.jzqb1onp6t.wasm"
    },
    {
      "hash": "sha256-gUSvjX+6UNejKoLelZmQYm2kTq9GIIpjAKp7jIG4MYU=",
      "url": "_framework/System.Drawing.Primitives.vcnhff6rpo.wasm"
    },
    {
      "hash": "sha256-UgmupMAr6ZNEzs9lDBX+BpCRqNkmfFv1kxoruuR2UWs=",
      "url": "_framework/System.Drawing.e1q21ukgul.wasm"
    },
    {
      "hash": "sha256-eLXOenftDYBxBnfnGCxTQvWhdVfXWNpM5JDraWHoAmY=",
      "url": "_framework/System.IO.FileSystem.Watcher.0yjaehogus.wasm"
    },
    {
      "hash": "sha256-DWDyZs31rd5Dadw+QGWLx2qLIY6e2auChIMr2bmq6Pk=",
      "url": "_framework/System.IO.MemoryMappedFiles.lybma0n3ts.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-ca/dl8Pu6l8g+wepzU1mv6ljYKAAQvodDGNLUWvuE+s=",
      "url": "_framework/System.Linq.Expressions.h4t00jfcav.wasm"
    },
    {
      "hash": "sha256-axzdXWZVYQVWRGuiMQN1jrSs/EGdNK8szE3ZkNlMB9M=",
      "url": "_framework/System.Linq.zudpuvhdrj.wasm"
    },
    {
      "hash": "sha256-D2JklocLNAbQbEKaY60K5RuQBnxBHk8QHdM9zfgSrMg=",
      "url": "_framework/System.Memory.xo7c8ljx2g.wasm"
    },
    {
      "hash": "sha256-VNlir/AKgDA3QkDpX/4ssjQDXRnllWt2MqiIkomAos0=",
      "url": "_framework/System.Net.Http.kwo9zcwpta.wasm"
    },
    {
      "hash": "sha256-LFFUw+y7horydgyMWIAXssriiTQGbJ47mY9wzsf3Ue8=",
      "url": "_framework/System.Net.Primitives.4syftxf0wa.wasm"
    },
    {
      "hash": "sha256-qBeVut0lHpsTmHmEWiuTywfoD6Es5ZVJCiWBJxyr1Qg=",
      "url": "_framework/System.ObjectModel.4pu9cmrrtj.wasm"
    },
    {
      "hash": "sha256-z0f0KSis593qJ8udcdh5SORBVOsL2epDnSgAS2ZPqX4=",
      "url": "_framework/System.Private.CoreLib.pm86bb1la5.wasm"
    },
    {
      "hash": "sha256-hib7oGxRwvilE5dv7tsoHoo0tzjB+RQpMy2yT8VGwuI=",
      "url": "_framework/System.Private.Uri.2yjauynx2s.wasm"
    },
    {
      "hash": "sha256-Q7J8wHHVbSu6tHwxFtcCfpg722zGbR6tM3cmiWVVJNg=",
      "url": "_framework/System.Private.Xml.9tag3gh6rc.wasm"
    },
    {
      "hash": "sha256-QKlMJphLYn4vVurQhHJNbOxTtWrfC3bE21YaHYDtbx8=",
      "url": "_framework/System.Reflection.Metadata.8e8jwa3pr5.wasm"
    },
    {
      "hash": "sha256-92zUoi9qwW2rZalWHIYTUNdUv+uUJLg6ZLS4Aj0eqHk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.5pcrya9j00.wasm"
    },
    {
      "hash": "sha256-iEhPTaQJ4jCeoj1L0EhagDRNRmxK7I6h9LVyXL2fxLk=",
      "url": "_framework/System.Runtime.InteropServices.gmhlr8xdyr.wasm"
    },
    {
      "hash": "sha256-3qlszhw7QwXhsqE1yoTe+XZV9DIKtZN8J/sjGoYd1lg=",
      "url": "_framework/System.Runtime.Numerics.m7hg7lwj0d.wasm"
    },
    {
      "hash": "sha256-Y040/yBtoV5Awgzqkpr4hx7b//OCLGOZ3CoPIKgqACI=",
      "url": "_framework/System.Runtime.Serialization.Formatters.zchqsmoxyy.wasm"
    },
    {
      "hash": "sha256-BrTcXVpcMj0NhQKBaDRg7vtHqRul7BZpcCXzser1I/s=",
      "url": "_framework/System.Runtime.Serialization.Primitives.mwzhov7ix5.wasm"
    },
    {
      "hash": "sha256-IqlpD5woUXoL3FkAnDthcnGaH03KPRjeDySD7XNJvgA=",
      "url": "_framework/System.Runtime.mnxf5byo7z.wasm"
    },
    {
      "hash": "sha256-PTco8KY4kSoDM193PlwnqLUKrXRAlwEDyONTdQcRV0U=",
      "url": "_framework/System.Security.Cryptography.dcg2cnjgw3.wasm"
    },
    {
      "hash": "sha256-w5BwYak22XKVBVhcVTdvJwLUzGTrnRdR7HuXyamu40Q=",
      "url": "_framework/System.Text.Encoding.Extensions.pdxtt9y857.wasm"
    },
    {
      "hash": "sha256-PVCrhDn4h1OgqMGUhEs25nlp1YW7mMfPoEgZxltnMoo=",
      "url": "_framework/System.Text.Encodings.Web.n7nth9auq4.wasm"
    },
    {
      "hash": "sha256-rFGBcmXPJ1MzJLA+i2HnEKn2XIJ2xx7FuBcKgjLklC0=",
      "url": "_framework/System.Text.Json.85jvvcv7yq.wasm"
    },
    {
      "hash": "sha256-3lEVRx+s2gYQnBPLZMGtJcTA+b1sJPnbdyw0h/2mErI=",
      "url": "_framework/System.Text.RegularExpressions.yrf4dz94kb.wasm"
    },
    {
      "hash": "sha256-0JCzu2i7CdmITLEigZ9IyvuvRTcd3Fb4JjQEzsJMXew=",
      "url": "_framework/System.Threading.sppono8m89.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-kq1sx7OeHV2+VlS55gnpzGL8LmfIFKjbh3A3ztC0fI0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-pA9IGmGGIrDuv4hMd1hTNflRlN4mTC40rUaOIzT0Tns=",
      "url": "_framework/dotnet.native.81njht3mfn.js"
    },
    {
      "hash": "sha256-wL9wJFGyk9uuO+TdzUZAAaBMsN8yug7Bb/+kgpySKpo=",
      "url": "_framework/dotnet.native.c5gej90lre.wasm"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-jpPq9/rW4hYaXX27b2AjTLB5m6i5MmolspqzXOFkymY=",
      "url": "_framework/netstandard.2rg7nnlvl6.wasm"
    },
    {
      "hash": "sha256-sB6U1B8Ayhd0JbpcytwEV733h6l928gnvMSWSxJA0Yk=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
