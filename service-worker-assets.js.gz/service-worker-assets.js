self.assetsManifest = {
  "version": "TbsUZ63O",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-EXjYrIOnAHfZPed31o2EABDl13fqEzWGToCYoO1v60k=",
      "url": "_framework/Markdig.rtoxc0wwut.wasm"
    },
    {
      "hash": "sha256-EjlAlQSFZcBStHUjEgqtUtPVZpLQgxLVowos0VmNvQY=",
      "url": "_framework/Microsoft.AspNetCore.Components.2smvwtc98t.wasm"
    },
    {
      "hash": "sha256-3WJ1wzWRmFyKK0IRm2dUYvOM+OVPfOWsvkMowIuu+Rc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.zgc06ajws1.wasm"
    },
    {
      "hash": "sha256-tDYBzcQK5kh7DGPPQu3OV1Sn/hRcv8WFYQDwGt211F4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ofogrz7inn.wasm"
    },
    {
      "hash": "sha256-6eUWhcuGl763hnVPxsWTP1a5oPSHc8QExDo4AafarLQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nwc3ueegm5.wasm"
    },
    {
      "hash": "sha256-VEZJWXQSvuTwGwue6+xVbajZjttiFMsHplrCafiaZOw=",
      "url": "_framework/Microsoft.CSharp.c0u7abl2v1.wasm"
    },
    {
      "hash": "sha256-37wHB/jlt93/ZOLjOd0siXKbtIoyo7J5j1UD4rSqGXU=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.lnxbcq1m3n.wasm"
    },
    {
      "hash": "sha256-ibed76Zik/v7fCxVLkhY+hhSUa1qhrNVml/L8ewVqL8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.70bnhsh86r.wasm"
    },
    {
      "hash": "sha256-CF+JUBJVrC4igJfWc0S6swocVEgyZ/Xw7xx7nlZZeHI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.o85mrs3iy3.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-nGd0qXnKGTZ/AIHp1e+4yoX85CwuTrPtBQ08V4R+Jrw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wvaqij7fjq.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-82wnsGGCWxkViFQWQU3oqP76NxfigUtefoozhlvXKQM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.flb1css1xx.wasm"
    },
    {
      "hash": "sha256-dyjqOZrh0fL9qXtviAqzKuApsnl/SKAIMcg5Eusesac=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.pkiabcs8hj.wasm"
    },
    {
      "hash": "sha256-NO53RqQrMDOWJB0E320Qiq1IlEuThKVy37P1ogAPEU8=",
      "url": "_framework/Microsoft.Extensions.Http.k2bj7nvdmg.wasm"
    },
    {
      "hash": "sha256-5cfqPNIcfFg6iqfER7ZrH5/6ebzxRWC1GneHKx4RUZ0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.xt3qux73ci.wasm"
    },
    {
      "hash": "sha256-BHoKPKvt4ZdSuINrzeAPuA0oAaLw4KjfLMPmaWk24UI=",
      "url": "_framework/Microsoft.Extensions.Logging.c2b4pc8e7c.wasm"
    },
    {
      "hash": "sha256-sldxDyMtJXutT8+BNdqKJFLWUJGx3/u8AmwmTz71Bms=",
      "url": "_framework/Microsoft.Extensions.Options.2fb2i8t3vb.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-CRM3xjoMVBK5MTDaU9xYmLR2QElURlK7MsNcegypPv0=",
      "url": "_framework/Microsoft.JSInterop.nkljd7l4yf.wasm"
    },
    {
      "hash": "sha256-s4t28jnu5nOUtgzTn+HfmakslV6vAl31glv59shIXHA=",
      "url": "_framework/MtgCsvHelper.52o6dyodnt.wasm"
    },
    {
      "hash": "sha256-izcw0i5u20PzdvifiizeUq19BQxgQHHnp6Ni62aH8ME=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.die8ts6p6p.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-NAqcHyy4QKrvpgRgbBVsZ9UggECikQNZLyJIXBxBknU=",
      "url": "_framework/Serilog.85x8wfinr6.wasm"
    },
    {
      "hash": "sha256-NHk6xRS3dIv7nLWuBUZvce3EXz7kvxiBsrjE7KvSMcI=",
      "url": "_framework/Serilog.Extensions.Logging.4aarm1ia2h.wasm"
    },
    {
      "hash": "sha256-kp2SCXz4fdsDb+fR+WFGpxe7oRlXLYbU5tSruqQUGHw=",
      "url": "_framework/Serilog.Settings.Configuration.aio2pf68g1.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-tMixsUF4GSgbd7+FHB6PICB4tUpDj29znyKxTr6gLUA=",
      "url": "_framework/System.0x1wb7tfot.wasm"
    },
    {
      "hash": "sha256-zMm85JVS+jCgcgf5F/LB9z2VUdRojViUmSCJh2YhFpY=",
      "url": "_framework/System.Collections.Concurrent.01x8lq4bl4.wasm"
    },
    {
      "hash": "sha256-H5Z3Rp7CeXY7nGdcZzCir33HU4Tm9XWLq/iO2w6Daoo=",
      "url": "_framework/System.Collections.Immutable.3f8qhizy2z.wasm"
    },
    {
      "hash": "sha256-LPKHiaytq37Y7mx/bwUrybhV4Kp9meBY0WNRwFEVcTg=",
      "url": "_framework/System.Collections.NonGeneric.440hbuh3c3.wasm"
    },
    {
      "hash": "sha256-rndGUgtza/rCkl3tugb0tMA3caqzeJPSah2BYUuIgeU=",
      "url": "_framework/System.Collections.Specialized.amjg96kszq.wasm"
    },
    {
      "hash": "sha256-uWf4AiySx9TkHWJF2LUJFMySRZ2rW/ofM8+1YGGwnUM=",
      "url": "_framework/System.Collections.zpezr6p80c.wasm"
    },
    {
      "hash": "sha256-8XnzGReXy7biNO4PmNWDcZNnes7lg8W1pdRU7GcTrJE=",
      "url": "_framework/System.ComponentModel.Primitives.z38obbdu52.wasm"
    },
    {
      "hash": "sha256-eJWKS/VNlu02Z/4YMEqtzpg1Ot3x5SJwqNoIEVFHD04=",
      "url": "_framework/System.ComponentModel.TypeConverter.02f5y2lrhj.wasm"
    },
    {
      "hash": "sha256-kibfwIYAZQ6CNW8r19cPzo6PtmO7UFLZKeOTa+pJbcw=",
      "url": "_framework/System.ComponentModel.a1ciwv5ake.wasm"
    },
    {
      "hash": "sha256-4KxaEkfzd4C7qnxCCeceTvlm8xfXZQdsAk/odO5UTkg=",
      "url": "_framework/System.Console.oauvsj2jiy.wasm"
    },
    {
      "hash": "sha256-lVnEFa9K6UeHebVj0OtHuuoXN5gx8FvWbWx4/c4VoIo=",
      "url": "_framework/System.Data.Common.vf7zypbqtv.wasm"
    },
    {
      "hash": "sha256-Ip3djXpHjTVWHWlFQ5WM0KkOjchbbanDX4qmEZXd4Ms=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.67qe9e0qxx.wasm"
    },
    {
      "hash": "sha256-zFcuaWsXFIQVzyPg/o6zJ03EiVbjZOIigm+bmqT8CGA=",
      "url": "_framework/System.Diagnostics.TraceSource.46f4mb5wb9.wasm"
    },
    {
      "hash": "sha256-TWqOAIv6MKua+eri/2iCwsGU5ELpNEgeVgkgY9NWPd0=",
      "url": "_framework/System.Drawing.Primitives.f5b9xx9ebt.wasm"
    },
    {
      "hash": "sha256-cwPGI68ueVqohpGFUXeVYVJ2KzT1QCSlQ5Rwnj1ngQ0=",
      "url": "_framework/System.Drawing.d8abg920y6.wasm"
    },
    {
      "hash": "sha256-b/kA6GT1ULCkjOqM+isX4ikoRkwSs40t5U1ywmQvHWE=",
      "url": "_framework/System.IO.MemoryMappedFiles.x03lc6awuw.wasm"
    },
    {
      "hash": "sha256-FWFhFxEZRtzlRy0d1OlgWHCxpJOCVc6uUn3yqvvXpYc=",
      "url": "_framework/System.IO.Pipelines.r4k8j9p1r8.wasm"
    },
    {
      "hash": "sha256-34hQmGaPkpgyLzAGs3ISQM0S1GNpdTtd8wTKVDawCII=",
      "url": "_framework/System.Linq.Expressions.nykz093ttg.wasm"
    },
    {
      "hash": "sha256-cJCRa7YDjY3nK9u+F3GLLkJ+WTreOHb6772uCggzZX8=",
      "url": "_framework/System.Linq.gkn1u5ru9z.wasm"
    },
    {
      "hash": "sha256-kzehYn+5Iko6HtoWm61d53Zb+PatFvA7p97H9b6qelw=",
      "url": "_framework/System.Memory.r2vx4u6ghp.wasm"
    },
    {
      "hash": "sha256-ki/1nHNQVbfivixBQB/zv0xoyHXmWfhD1Z1FICdLmSA=",
      "url": "_framework/System.Net.Http.2vl76gihgg.wasm"
    },
    {
      "hash": "sha256-plHxgH09JKpwQgM6VKoolDp+/W1iDi95M2dJMferqKE=",
      "url": "_framework/System.Net.Primitives.yl1uus6nzv.wasm"
    },
    {
      "hash": "sha256-DuztXZatHarjOWvJpMZXVIcXy4w4RW2w6xh7VmCzUxY=",
      "url": "_framework/System.ObjectModel.mb9r4qo88k.wasm"
    },
    {
      "hash": "sha256-zLc5HpdCZ8GjmZwcZMhcDabav4lpXLIEzcEgcxWJdrY=",
      "url": "_framework/System.Private.CoreLib.0pf7ds6yfj.wasm"
    },
    {
      "hash": "sha256-qn9iQ71/lm5VIPRLTk3WFmGcZPL1SPl8SQM1vsTxay4=",
      "url": "_framework/System.Private.Uri.m5eg8vnuen.wasm"
    },
    {
      "hash": "sha256-gtvklsTXzYjvZrOc+rA1WLYUikFCkFk64ZnUSHZcyJw=",
      "url": "_framework/System.Private.Xml.q1c2nxqtwe.wasm"
    },
    {
      "hash": "sha256-YSJtBwcza7fBgq+6C9QbumYhtu8+xGc8NmLg+bmBz0w=",
      "url": "_framework/System.Reflection.Metadata.nm7o1gwvqm.wasm"
    },
    {
      "hash": "sha256-p6/wV05PEoKocillIiVPYCnVVIrkHEzHoyxRM/6Uc8A=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.hq2mpklnqr.wasm"
    },
    {
      "hash": "sha256-HRqqFNMv+p7tQOwVoe0r8/mXbQqU/KY1UGG3W5nR3SQ=",
      "url": "_framework/System.Runtime.InteropServices.b6ou4fj7w6.wasm"
    },
    {
      "hash": "sha256-8AmROZgDGT9B/FWf2Ip8S7tIFVoO1ELAt2Pxub6uMWI=",
      "url": "_framework/System.Runtime.Numerics.0wfm82gn6w.wasm"
    },
    {
      "hash": "sha256-0pYcGTBjFXt72/JCgcXt5hdVroHPp+gCOs0xL3hQlcc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.ehuaecum9q.wasm"
    },
    {
      "hash": "sha256-J44xHlCQ6/m3Umi0eTdnSdrSODIMR9bb9eSt3T/LPXY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.5l2je0puqv.wasm"
    },
    {
      "hash": "sha256-eXnkIzv/5PtzyORKTjj681EZla1ZCFyZSsCiNVU/oaM=",
      "url": "_framework/System.Runtime.l1g5ld92ga.wasm"
    },
    {
      "hash": "sha256-Es8z5MrknUcTNEbgWClzoRLnmasi33Gea9tRdgF40hA=",
      "url": "_framework/System.Security.Cryptography.qa9sxg7l7v.wasm"
    },
    {
      "hash": "sha256-0ICK1urofcWmz7vV1/rHhXYnpHG221DbVVUfWMinzcw=",
      "url": "_framework/System.Text.Encoding.Extensions.0w3al6sujs.wasm"
    },
    {
      "hash": "sha256-MyAO765XzYoxMH8f5cEfKjUxPzY2BEcrdN2mmFFBeSk=",
      "url": "_framework/System.Text.Encodings.Web.nrlwe3nrlo.wasm"
    },
    {
      "hash": "sha256-KpJkEtyJ8xPTxROxfJrimBzJbhpB+RIotnIXfo0IxJ4=",
      "url": "_framework/System.Text.Json.q3tm5ziynb.wasm"
    },
    {
      "hash": "sha256-Fmzh7L2UkxiidgtlX88Qq4RjOqSVjkrQO+vQvitvAXE=",
      "url": "_framework/System.Text.RegularExpressions.ubgxzoa3h9.wasm"
    },
    {
      "hash": "sha256-OC6zNNASKDBbR810ugV7/6/wrKuaexLOXfvUzjichuA=",
      "url": "_framework/System.Threading.ow6tu6ro1k.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XxTROATMDSj4iO+0vsd493MVvw+C0YwZVxIbxQIODj8=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-NIz5/qd87BnEENnkvFPs5zgy3lyuQDQeH68sI/84BJo=",
      "url": "_framework/dotnet.native.gz5eq599lg.wasm"
    },
    {
      "hash": "sha256-Vm2qQOZbsi6/fu9Lkhq2BmfRM6gviQmNp5TFJVwkRo8=",
      "url": "_framework/dotnet.native.iqjbubr360.js"
    },
    {
      "hash": "sha256-/ndm/PF1BeBT5mXzYAES79wNK5sIZIQKAGcUqPL9ZP8=",
      "url": "_framework/dotnet.runtime.2zl32tp6ah.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-pO+ruPYSgYOKLyXeFhmoN/PCECTy6OGVlNtlLuLFnso=",
      "url": "_framework/netstandard.0vs18gos38.wasm"
    },
    {
      "hash": "sha256-YPIE1jZvlqLaxW9Wq5ib7HYmXDLkodyhNgJbkJpgIX4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-blNd7Wq50QblKVt+6O0lcfM2mBMZmGaY+NIByYxn254=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
