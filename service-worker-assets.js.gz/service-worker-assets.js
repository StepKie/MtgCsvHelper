self.assetsManifest = {
  "version": "+Rp/phnk",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-FmTlxxpIFc2Z0WjzqYJhEKJYyc+6rzXeVQyYkH6IPZk=",
      "url": "_framework/Microsoft.CSharp.iem2usn6u8.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-bZ/46ErPqcHTAkKEFltTtCjC8Xv0GpBuyzoWNb1mlwM=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.jkj64lskmp.wasm"
    },
    {
      "hash": "sha256-c8EWprEXwZIzlqtWIwKbDZtUafVen29jGKGW3/sZHX4=",
      "url": "_framework/MtgCsvHelper.fdlh7phvr6.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-+/3A4lrXGyV1SI30Q8J0ONqqPp8Xhc5WJ4ABmiKHtpQ=",
      "url": "_framework/Serilog.v3jtg2iuay.wasm"
    },
    {
      "hash": "sha256-Df+ZQIVwhbDzyQ2ppDouCtc0FOZyFPlrKqQTLbEhFr0=",
      "url": "_framework/System.Collections.Concurrent.r6oakxza53.wasm"
    },
    {
      "hash": "sha256-rONDKQSB35sUGwuapSnIA+PzZmyVG7JR+Svt+3yML3w=",
      "url": "_framework/System.Collections.Immutable.07v72mbtqt.wasm"
    },
    {
      "hash": "sha256-CUbxJmh4tHSUweQv5O2ECPI34wVYlQaXlnnneGxDcxo=",
      "url": "_framework/System.Collections.NonGeneric.jxsaxupqzz.wasm"
    },
    {
      "hash": "sha256-2N79Z2b9VE5lC7N14OEGgVgUvCIyx9FMHH28H6OGVWA=",
      "url": "_framework/System.Collections.Specialized.we0nl2s126.wasm"
    },
    {
      "hash": "sha256-Eo1fUWhjimWZEbxQWFBuuSeQqauB3aqiCM6HfprC4GQ=",
      "url": "_framework/System.Collections.apaji18l3x.wasm"
    },
    {
      "hash": "sha256-kbhkyF3IgQ8L4HwwfmFCqPwYB9gMGMdN2oK4B8V301w=",
      "url": "_framework/System.ComponentModel.Annotations.lz94xz0mmw.wasm"
    },
    {
      "hash": "sha256-YFoMaUyexQZbKneP1z1he4CJxza1GPKlGwmQhtnOoPE=",
      "url": "_framework/System.ComponentModel.Primitives.om3433aocx.wasm"
    },
    {
      "hash": "sha256-64bPGWY1nq8en4JV6ZW16nMs743XHmqSAlSWWnxMEEA=",
      "url": "_framework/System.ComponentModel.TypeConverter.ffwv9awz7v.wasm"
    },
    {
      "hash": "sha256-wVelT5q2Ayvz9D1JWzDUNVki/rxamE8kOKs/ckVx+70=",
      "url": "_framework/System.ComponentModel.vcj9uwgm8b.wasm"
    },
    {
      "hash": "sha256-xopEudxoq/KHVXDSUnIaPCPzrwrECbXHukPN07yTVbI=",
      "url": "_framework/System.Console.awvbnik7hh.wasm"
    },
    {
      "hash": "sha256-QMjFLgx3NBQi6gRg+oB6BaWDdlQJ0nwCEo28oJmm3x4=",
      "url": "_framework/System.Data.Common.ch13alqdjg.wasm"
    },
    {
      "hash": "sha256-LMhOvuLDNyJqcS8tUXeTUNuUg8/aYAFu8DcWrtIXp2Q=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.c8slqvlruo.wasm"
    },
    {
      "hash": "sha256-jMNzKitNSZ4dIObxM4VzmILcBnhtHER8/jZRWaNvKNE=",
      "url": "_framework/System.Diagnostics.TraceSource.kib5mpmj8w.wasm"
    },
    {
      "hash": "sha256-ryYAeFRPYW3oj8EiReDLk0BicOHBVRSgBle43T0N1Y4=",
      "url": "_framework/System.Drawing.Primitives.9igjbt8kmm.wasm"
    },
    {
      "hash": "sha256-v8fB+rYlrZlKumwHku/jCAAn4sl4ga5n9OfjpWDMAxo=",
      "url": "_framework/System.Drawing.r5f079tipk.wasm"
    },
    {
      "hash": "sha256-6MdtHnYMUiJ5HcfVoFysvHXKPzdstk0Jn3KCo0M6rHs=",
      "url": "_framework/System.IO.Compression.457jdcsm4k.wasm"
    },
    {
      "hash": "sha256-R9gh3/HOVh93Ml/EeW98iGSfDf4O5h77Cy9xb9SdMCU=",
      "url": "_framework/System.IO.MemoryMappedFiles.n85jfe5mq0.wasm"
    },
    {
      "hash": "sha256-BQzN4FegYIbktpuD/Qa8j0frtjP1d3lVZMuzihcmczg=",
      "url": "_framework/System.IO.Pipelines.bs0ouzxqxi.wasm"
    },
    {
      "hash": "sha256-P2Hra2SWYfmNNAKyOuQQDedEHGsb6OK1AyNpXap5dGY=",
      "url": "_framework/System.Linq.147v1iwlcv.wasm"
    },
    {
      "hash": "sha256-cn4CTx0YJyk6jnVWXx5XGdP0pgiEJ5ocYN7PDpjziwI=",
      "url": "_framework/System.Linq.Expressions.2wb1wfd0un.wasm"
    },
    {
      "hash": "sha256-rr9n3KzmKpnJdeNWXMfuMjB84Le1d6o6FO4xczRMmD8=",
      "url": "_framework/System.Memory.i0oby0djyp.wasm"
    },
    {
      "hash": "sha256-zK6/RKH72y6VTIHdPXkHUMeYy79zEAnJy56f+5OM1WA=",
      "url": "_framework/System.Net.Http.w9ppdmwb06.wasm"
    },
    {
      "hash": "sha256-PFjB2kXVWw0Ir5zfjx0pizeB4xCJNsFFyeUDCVszVis=",
      "url": "_framework/System.Net.Primitives.wr5ku4tjce.wasm"
    },
    {
      "hash": "sha256-/icDwiiQ/baCBdGdWhIr4gTCW/0YztgR+sEKW/wwNxE=",
      "url": "_framework/System.ObjectModel.ykljsm7nem.wasm"
    },
    {
      "hash": "sha256-72oJVjOVgKIZ+u/x8w9Z+ZMA1bkBBNhwxwsTe2GC3PU=",
      "url": "_framework/System.Private.CoreLib.vovujvq8df.wasm"
    },
    {
      "hash": "sha256-JxN3p2XqHlTWI6uVRaOle/LmjJ3Xol7O9i+FKW58bjw=",
      "url": "_framework/System.Private.Uri.tfevyskoug.wasm"
    },
    {
      "hash": "sha256-cEMDjv3CzwRsVFR/q9TJ1oQrh++Kz8Ljif7dDQoLVxs=",
      "url": "_framework/System.Private.Xml.4fxxk6fnxw.wasm"
    },
    {
      "hash": "sha256-hGHGbxpPhtJL7w/p9Lgwa3Jv5O87BXSs/JYS/JzeHGI=",
      "url": "_framework/System.Reflection.Metadata.oftmbqhq1d.wasm"
    },
    {
      "hash": "sha256-Mm8PRt+ZQeAALS9DXJL7mxSqJAuWzhige2A6I9Kq0Ts=",
      "url": "_framework/System.Runtime.InteropServices.24m15tt7lr.wasm"
    },
    {
      "hash": "sha256-zq1trH9fVIqMa7vwozyAnXe+NxfFe4ZZyE66kiy5YPE=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ett5kilrdx.wasm"
    },
    {
      "hash": "sha256-TarARWttnmiIyJaxH7jFS533wCeztx9bof8BeTx5ShA=",
      "url": "_framework/System.Runtime.Numerics.jcvc4iauiv.wasm"
    },
    {
      "hash": "sha256-eKjRtJ59nYBXmX36Bu8HjEebUB1NzWeAS++MFjCKWhU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.0u8vq83nzp.wasm"
    },
    {
      "hash": "sha256-vJsIfIYBtF3mSJNvrzdH6PZDCHiG7rxa4YziaXWHOIo=",
      "url": "_framework/System.Runtime.ghtw7cz7md.wasm"
    },
    {
      "hash": "sha256-q31HkQ/n0VXcps7BBJ0DsEcUbJDoGh7pItNRoZfoGxg=",
      "url": "_framework/System.Security.Cryptography.pfmn9mjv3n.wasm"
    },
    {
      "hash": "sha256-uF51o2akkBfYdRZfqe4FJkun9DPGti9FT4qulezA4vU=",
      "url": "_framework/System.Text.Encoding.Extensions.ossad590l5.wasm"
    },
    {
      "hash": "sha256-Evx0RHgDkznpVSTq6H+NOJB1An2uO0YVraS4H+ENM04=",
      "url": "_framework/System.Text.Encodings.Web.yvv2abe799.wasm"
    },
    {
      "hash": "sha256-1J4iypo1DUHgGzBpHvHh95WHXpVlNaxGuWLwmyKHsw4=",
      "url": "_framework/System.Text.Json.keikjdsfae.wasm"
    },
    {
      "hash": "sha256-6fENGlUXA+3MH4p2FIC+mpMEJQC/HjqY5VRifT6vn7c=",
      "url": "_framework/System.Text.RegularExpressions.jhmt7c6ij3.wasm"
    },
    {
      "hash": "sha256-Xe9vISnAefE1ObHrBMX7rPmnJVBb7TqvZK6SAUA2g2M=",
      "url": "_framework/System.Threading.hrogynbxcs.wasm"
    },
    {
      "hash": "sha256-Gs5bAip0Y07Y7rdk4CYnpzrBeGplAudFAELUELfBy80=",
      "url": "_framework/System.a3z5tpzyvn.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-xx0Twjw/e4yclx0cuiDhH1FFvlznW6beaztJ9RNxnBE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-T2JvlN5+cWS+e7TSrKWHVlpIRmlG+TSIA1Y3P3WJllA=",
      "url": "_framework/dotnet.native.57bgln1gj4.js"
    },
    {
      "hash": "sha256-XHl6/T1qf9LJTfYhdAyVonYzdtNnwuQ33ubOrD+/fUo=",
      "url": "_framework/dotnet.native.gphwd2rxrt.wasm"
    },
    {
      "hash": "sha256-/3dBg9sj1yLD3h0PDMHnNUXWs/2zWwIMEzom1Xz3Q40=",
      "url": "_framework/dotnet.runtime.5nc8i5dl74.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-5DiC3wvmy7Lcnb+XKJJBE7+t36kkeC9NxZUj+Now0oQ=",
      "url": "_framework/netstandard.46of3rzdi7.wasm"
    },
    {
      "hash": "sha256-OVdd3PpMznuWCRsm073NkDNne0opNWFEdQ0WdkVAF+Q=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-C+I5UiWekPDP2rLR+IJ/v0Gf4rcsm5CzvTQpPFY4KcU=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
