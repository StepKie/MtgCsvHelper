self.assetsManifest = {
  "version": "LH2ZflCv",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-T+ZlqWTwT75VAAbXtYLbfm+Y4Sq3KSXbzMlTEphdF0I=",
      "url": "_framework/Microsoft.CSharp.7mbif34lhw.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-KxmtUAtHwMF6jssIN7aM6BYUtALzz7aN2PXCGIpV8vo=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.vbsb5gx1f3.wasm"
    },
    {
      "hash": "sha256-nzvdu+MnejcViFm2/zAVMzEzxTxtz5jOVYEsaD0U6hE=",
      "url": "_framework/MtgCsvHelper.jnpfc8mc3k.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-IilH9xUSfCv0ovcxZ9JX2p6BKnBsYgo5dmDW7WQNKqE=",
      "url": "_framework/Serilog.mutfikrzmn.wasm"
    },
    {
      "hash": "sha256-FfEzz/RMrqtQt6PqxByGmuxkvSwq9AuTOAWDESX3xwY=",
      "url": "_framework/System.Collections.Concurrent.tah605iw7r.wasm"
    },
    {
      "hash": "sha256-MyKA/r1udMH4FYxOuWS7Nc7ksmtwWfCS9MTHfTBVkM4=",
      "url": "_framework/System.Collections.Immutable.dch45636ie.wasm"
    },
    {
      "hash": "sha256-Pq0+PQyltmMbTD4ndBeiMvq6cIFdRIpy0EvpBii1Wis=",
      "url": "_framework/System.Collections.NonGeneric.6yjpw7yb9q.wasm"
    },
    {
      "hash": "sha256-WwK0ThO3i7PfUEv8UUi4b8r1xu2cxbXiYss0f+Mmi8E=",
      "url": "_framework/System.Collections.Specialized.tys4ae5ws9.wasm"
    },
    {
      "hash": "sha256-RCyl77daojjXetK3Wmj0U5MpIZtbeT8dXtN9ARpSPu4=",
      "url": "_framework/System.Collections.opyw4qbers.wasm"
    },
    {
      "hash": "sha256-Twta8TU0oH9VpII7RZKkWAB+9/C8RickB9r1Lu0MbcQ=",
      "url": "_framework/System.ComponentModel.Annotations.7qmxa0d0yf.wasm"
    },
    {
      "hash": "sha256-n9jf3InsQgORGzgpebPf+r4k8DaRRkKhZvOiKHXcCLQ=",
      "url": "_framework/System.ComponentModel.Primitives.xchir1q36z.wasm"
    },
    {
      "hash": "sha256-MwaMLbAqeVIjmE86R3VU1AHfsMO+YPjJLVrJ0H6zwbg=",
      "url": "_framework/System.ComponentModel.TypeConverter.bm1g2m4sg2.wasm"
    },
    {
      "hash": "sha256-4hwp7Nx4cFmR8tAXl74lHAVXTRYJk63IpvD+/OxUZGs=",
      "url": "_framework/System.ComponentModel.eo3a2wv09j.wasm"
    },
    {
      "hash": "sha256-D4dN9LuV5/QZdnACzPtzu5qB6se6jQVTA1T8Mx9d6pk=",
      "url": "_framework/System.Console.bxm0v5emhg.wasm"
    },
    {
      "hash": "sha256-NcNt+XwWvJ9eZRO7inCD37yK2ivFXq7ZvmKCAjmLexI=",
      "url": "_framework/System.Data.Common.h5nw259iqr.wasm"
    },
    {
      "hash": "sha256-SDdRtPXhq6bzdeXuyOeIzjQWjSOqdF6PvdlJ6wH5QeM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0admgrgio7.wasm"
    },
    {
      "hash": "sha256-PexcayCM3psA4xOU+y4DrgQC6PgJDNS4UP4zT4dB3Vs=",
      "url": "_framework/System.Diagnostics.TraceSource.ph0b5c4siy.wasm"
    },
    {
      "hash": "sha256-367ULC47N7z9+sCPSlPc6PVHjoNvLwaxVWAirjTLTz4=",
      "url": "_framework/System.Drawing.Primitives.dlexl5isip.wasm"
    },
    {
      "hash": "sha256-+i9M56pVn/GMPC9adMYhiqJnUwVUVA/TNNHIFiqY5cM=",
      "url": "_framework/System.Drawing.u2yalkg4b6.wasm"
    },
    {
      "hash": "sha256-RBaH3vyXGtAg5CbRgQ0h988wCBSMq+7Tf/zNxfgwVbI=",
      "url": "_framework/System.IO.Compression.ory5r3jn9w.wasm"
    },
    {
      "hash": "sha256-Xdnb+BO4cn5a29x/4Zdg+sUIw8co9wcPEyHfaopJzN0=",
      "url": "_framework/System.IO.MemoryMappedFiles.hzyd7sxmi6.wasm"
    },
    {
      "hash": "sha256-F+momQ5WP4xfA/Vq9jEIevqHrrx2YXHsyrF9owt1h8w=",
      "url": "_framework/System.IO.Pipelines.rn8hjkm2d3.wasm"
    },
    {
      "hash": "sha256-AjV5Oy2Ewv9rTx2GqPEAB88GX6uhulyvUc597UQD7XU=",
      "url": "_framework/System.Linq.2c1h879ooc.wasm"
    },
    {
      "hash": "sha256-earsq6OfXGRQKjEgbd+/Dj+Ci/ENW9nv9r2DxTIP+/o=",
      "url": "_framework/System.Linq.Expressions.5pzjbdzcs5.wasm"
    },
    {
      "hash": "sha256-yenqFVl1VwalS0iToiFX1VOGB1iavDu5mjDLWiK6GnE=",
      "url": "_framework/System.Memory.f2m26hhu5h.wasm"
    },
    {
      "hash": "sha256-YOOJSWI9pm5sA58jBtVQVxtJ/U2KP8cw5i79pFOcxNE=",
      "url": "_framework/System.Net.Http.w4zeu762pt.wasm"
    },
    {
      "hash": "sha256-C4nd2FMYx8O50Glv2OJUP2Op4MvYMPrMBDQWtU/ic14=",
      "url": "_framework/System.Net.Primitives.h5zwp9gu66.wasm"
    },
    {
      "hash": "sha256-2aW+Vo+7DJK3Ri18z1vb16wbNsZPSqGkB4ztB78oRfI=",
      "url": "_framework/System.ObjectModel.7s7flks3n0.wasm"
    },
    {
      "hash": "sha256-Yx5tPx6fxUcOfAtoN3GSGdr5s0kpb6FG1+/9Z0yU3hk=",
      "url": "_framework/System.Private.CoreLib.vpckx8o96z.wasm"
    },
    {
      "hash": "sha256-sgSSx4la/fsjrwz6oomIu9CiH3RbLUyK35fXLpUsUHk=",
      "url": "_framework/System.Private.Uri.iosijgrvnz.wasm"
    },
    {
      "hash": "sha256-SGtdhD6XBquNu/5dhXvxyNfMHOAIjdUoi9ZjXflosk0=",
      "url": "_framework/System.Private.Xml.kl36d8f065.wasm"
    },
    {
      "hash": "sha256-YGXUtfbqfpvF3n2T3XwoUm5L8Zz0WnTqpUAXSk3o6Xs=",
      "url": "_framework/System.Reflection.Metadata.s5tssbnc7e.wasm"
    },
    {
      "hash": "sha256-NPa4kaorc2hTkqqb6czohxCjlKMMb5f0RfHXmdMJYfA=",
      "url": "_framework/System.Runtime.8n3fmkd7ew.wasm"
    },
    {
      "hash": "sha256-PqykTsnB/X8Wd8ZWRG6+IlOUa+0hu2JCcbXmx9FyDII=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.6ec2lj6df3.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-22asxDCg7yRyhOUd/mon89ehZ8Rq4hBX0w2iJw0zVXQ=",
      "url": "_framework/System.Runtime.Numerics.bc63off6od.wasm"
    },
    {
      "hash": "sha256-vVy32/5+cUf2OUAVcTfFzb/zCBWU4Eb05nqSmGdrtmE=",
      "url": "_framework/System.Runtime.Serialization.Formatters.bm2ga2q0ou.wasm"
    },
    {
      "hash": "sha256-5ahlao1phYmQwIjO6OorTjAKyCrGddXEISyuQCBXC+Q=",
      "url": "_framework/System.Security.Cryptography.f7pad792va.wasm"
    },
    {
      "hash": "sha256-531D008FjDTjPr0whjckTfggKHSkkJHZL7PB12VuHMM=",
      "url": "_framework/System.Text.Encoding.Extensions.1uq5f7gico.wasm"
    },
    {
      "hash": "sha256-S/TiO9VkAEsOqdPqHjq0Z1rHDG+TMrZmL6dM5T5Nj1s=",
      "url": "_framework/System.Text.Encodings.Web.7dvilcu3lm.wasm"
    },
    {
      "hash": "sha256-17GQpVaDvwAWDOylKlX06rfjK2vLtJBdDTitPv1GB4M=",
      "url": "_framework/System.Text.Json.39t7qexreb.wasm"
    },
    {
      "hash": "sha256-F3vOnvk4jUMWAyGDCZi7UaHWxFzECzzLZoMDE2IFiYo=",
      "url": "_framework/System.Text.RegularExpressions.74o4cjf62x.wasm"
    },
    {
      "hash": "sha256-mYByekB4qBb9huNNgEGedCTTKN07m1tmUKEjl3XX1C4=",
      "url": "_framework/System.Threading.r32zyyitzl.wasm"
    },
    {
      "hash": "sha256-TbXBiQa38E2TrjWSwZYk9l9sTztp8pQ4MLJyVPBpaEk=",
      "url": "_framework/System.nnqvudo0vd.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-11xdtvS+jYsarIOA36h8I3AYCB/X8LbKuNp8+0okff4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-SKVdYsSkkMxMC7ZUv3BiNtpfY5OZfwW6d4kYNvK98p4=",
      "url": "_framework/dotnet.native.0auspdp6oa.js"
    },
    {
      "hash": "sha256-i7OFO6/yserD9MKixxppnAMFbUm5IvPyL7sqW5xBDBg=",
      "url": "_framework/dotnet.native.pzzp2u1dp9.wasm"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-TGB/57izW9gkIIHyTjlelD3lVIO89SXAoZAMI4/0krw=",
      "url": "_framework/netstandard.oxdr1oi7w4.wasm"
    },
    {
      "hash": "sha256-4uRUUCyvo8ptI44f3pK3+1bV89dD2TG5qBDtwRu6LLU=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-1T1nhtp2LKuFeKhNPxDzfGHqeLD1Lrq9f3PKyL06/g8=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
