self.assetsManifest = {
  "version": "NsQCGF87",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-b5+CBbtpGI9BQJETdt+ZsgT0lFNYl9qQDX5Z8dz/HsY=",
      "url": "_framework/Microsoft.CSharp.btx1uw6i5j.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-NOMXklCij6T8LI1Yw/8+bH24rQTvQB5Abzo5LgpEUXs=",
      "url": "_framework/MtgCsvHelper.0jama97bqa.wasm"
    },
    {
      "hash": "sha256-I/sTfnltu88QQPHUIqVjDnbTk2wYF0hQMSiAX29g73g=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.rud4wr312c.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-+/3A4lrXGyV1SI30Q8J0ONqqPp8Xhc5WJ4ABmiKHtpQ=",
      "url": "_framework/Serilog.v3jtg2iuay.wasm"
    },
    {
      "hash": "sha256-vPEm2KqgXqruGwnz718iSgmDoB8Img7iH3FzO57b0Rg=",
      "url": "_framework/System.400l3mulw9.wasm"
    },
    {
      "hash": "sha256-JvSUC7AwY6wuhWlTa/cIx1jVywGbLquSc7Kpaxpin9Y=",
      "url": "_framework/System.Collections.Concurrent.yhimdws2lf.wasm"
    },
    {
      "hash": "sha256-iprv+8KVvMohzsqAvXHUIN3+yH8OYkZVJZLzfGMDQG4=",
      "url": "_framework/System.Collections.Immutable.ie4t7axk7i.wasm"
    },
    {
      "hash": "sha256-vV1bz0uaH82+I4uPFoVe7b/Czm1jEWP45/Act6fYpiw=",
      "url": "_framework/System.Collections.NonGeneric.nzkomndb61.wasm"
    },
    {
      "hash": "sha256-NvttRGdWDxk+twPVi4tpjuJBg19O5c5e8JDR4Af0QN4=",
      "url": "_framework/System.Collections.Specialized.em9unq19z1.wasm"
    },
    {
      "hash": "sha256-DS/f2W9UJ8ljDpTnZTmDb6tr59RzWAx/fresxZjgbsw=",
      "url": "_framework/System.Collections.t4itynddx0.wasm"
    },
    {
      "hash": "sha256-Um+Cf48098QV5/A7DFPkgVKQPdLpm8s7kWO4vt+YnOc=",
      "url": "_framework/System.ComponentModel.Annotations.epcka6xba3.wasm"
    },
    {
      "hash": "sha256-bIf80QXWPyGu11cT6a2tDXcJO6JKty+rbec+q4mkXHs=",
      "url": "_framework/System.ComponentModel.Primitives.kstf05gsnn.wasm"
    },
    {
      "hash": "sha256-kMsq+XB+q83SpXoDB5t33eA+tgBumtgLyEFe5P6W5s8=",
      "url": "_framework/System.ComponentModel.TypeConverter.cd9c2a95wg.wasm"
    },
    {
      "hash": "sha256-oFm4vMv+Q9oyEejMC9gEG9e7ko8IcrpkPHiy/Dg8F3Q=",
      "url": "_framework/System.ComponentModel.cphsh41vl6.wasm"
    },
    {
      "hash": "sha256-VK8eiWedVu4xBr0e9qLe5xuPY0lGLhrwY06KTzCXTUs=",
      "url": "_framework/System.Console.09pq5ioace.wasm"
    },
    {
      "hash": "sha256-M1WtzHZuizWIArJaLtXlylEKcdN1371TdMdWFvNtXw4=",
      "url": "_framework/System.Data.Common.xz0b9i6p2h.wasm"
    },
    {
      "hash": "sha256-5lxkl/zE9EX1TiVvwxdhVzL5fYWvybqA5lC5UoIDhQ0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.u3dvj7ivvj.wasm"
    },
    {
      "hash": "sha256-xcBrPy9loXGzSVzHphW5BXIR+v2abXQoZJTLhOQKDVk=",
      "url": "_framework/System.Diagnostics.TraceSource.z6kw9m5whi.wasm"
    },
    {
      "hash": "sha256-NcLcaCsp5uU1sg9My5OqdCmZjG78tKLZG0Skdfvb/zQ=",
      "url": "_framework/System.Drawing.Primitives.lgmq6iw2qm.wasm"
    },
    {
      "hash": "sha256-NFpXLgCTsyBU+AK+27QTsQQxyAoaLo/HDVh9RRvDIL4=",
      "url": "_framework/System.Drawing.c6tmp1gjc8.wasm"
    },
    {
      "hash": "sha256-JB+J/3uu81R7305aOuPiz8gzk4VKSnVLtLC5POl829Y=",
      "url": "_framework/System.IO.Compression.o3qcwc0tj7.wasm"
    },
    {
      "hash": "sha256-vXggeRAkTcc//eTGTZfucmxZIsP0wNbPP3gXnapnTtU=",
      "url": "_framework/System.IO.MemoryMappedFiles.ppy01ujboh.wasm"
    },
    {
      "hash": "sha256-jOc148Kum+vuUrg2BtnLWI7ETSeWMNGiicdYKMEGmrU=",
      "url": "_framework/System.IO.Pipelines.syhqffnboi.wasm"
    },
    {
      "hash": "sha256-N12DIuS0c5SqQvJ4gH7u1PeXKcFDlVktwU/FVP+6HsM=",
      "url": "_framework/System.Linq.Expressions.hy7qsfkqlq.wasm"
    },
    {
      "hash": "sha256-B546gE20EAFdDfoVuGMmOKhoHiiOoZKyGRpGa30QrE0=",
      "url": "_framework/System.Linq.jxx5z4tog8.wasm"
    },
    {
      "hash": "sha256-U03Nsx5ZPlHfeShON1ItGu+JpazcikileoDzDuRY9Mo=",
      "url": "_framework/System.Memory.dw6zxxw30o.wasm"
    },
    {
      "hash": "sha256-LGwTk3jYpWpyMGzjtWe/AU1Z90qx30i4FMjdXefkeF4=",
      "url": "_framework/System.Net.Http.4imx4ekrqa.wasm"
    },
    {
      "hash": "sha256-Ia/NE6xAMh/SHTLkaYSshpnurJUpxy1+SATrDeEXkro=",
      "url": "_framework/System.Net.Primitives.b5u59ctka3.wasm"
    },
    {
      "hash": "sha256-qls8WQgw+mQyhmfj7pJ52eZan87LYaGxfL4BZCXz4X4=",
      "url": "_framework/System.ObjectModel.q8fuv5wcml.wasm"
    },
    {
      "hash": "sha256-0aV7lVbvnGWWUouap4n9aKvd2OPwlCLdnhz2fU7KvhY=",
      "url": "_framework/System.Private.CoreLib.3vds1l57sn.wasm"
    },
    {
      "hash": "sha256-VvuKpabJk6Me9X8gWwXp8BM4v0o9DLIaDJsPqZHWht0=",
      "url": "_framework/System.Private.Uri.il97761u8k.wasm"
    },
    {
      "hash": "sha256-E8V+j8AKISkoiTKTNieGY3x9Q9liH6xbfiduEJtrw+o=",
      "url": "_framework/System.Private.Xml.f16mp1imj6.wasm"
    },
    {
      "hash": "sha256-dMuogTpm6M3Vc9Eh292/M8uzKT6akjojyyFyPp3QXsA=",
      "url": "_framework/System.Reflection.Metadata.cww8gvv80m.wasm"
    },
    {
      "hash": "sha256-w1/cz8m0+ZMcgL9K55ipfoak8K6bhm02YyCIc1HiHgU=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.j4mrr313ja.wasm"
    },
    {
      "hash": "sha256-zYAp8xLvtlOxalhozgdd7lV0l9NwVhdU3rOeT47LDIY=",
      "url": "_framework/System.Runtime.InteropServices.zsicxx3i3w.wasm"
    },
    {
      "hash": "sha256-11sfvPvWws23FXy4+Bvib2E70viWhBdKbKXA8h9XGrA=",
      "url": "_framework/System.Runtime.Numerics.p0t1ro8my6.wasm"
    },
    {
      "hash": "sha256-voORWMPpD1uJ01c2p5OFpissWHEKz6ro5Bjila/Zexg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.6n8e5hht2o.wasm"
    },
    {
      "hash": "sha256-ddrHBcJe9tbBnEmiFPXTH4N86iacmAcp8k4jo/egYtA=",
      "url": "_framework/System.Runtime.r03d5w3cay.wasm"
    },
    {
      "hash": "sha256-JRyMpBjBfFKB1/g2YOKtiLGB1RbQJ8eFUFDxu49AJ8A=",
      "url": "_framework/System.Security.Cryptography.jq63z3n18s.wasm"
    },
    {
      "hash": "sha256-xlzDXaEN8BlJZ/cmxpvjDbpYqmXAnU9S7pNhE10wL74=",
      "url": "_framework/System.Text.Encoding.Extensions.ajdtrmih3n.wasm"
    },
    {
      "hash": "sha256-kZNBlcYyb0tOPujtejwKDay0z39Eya7LJuyVLvp7Nx0=",
      "url": "_framework/System.Text.Encodings.Web.p2n7buggi3.wasm"
    },
    {
      "hash": "sha256-l+h7Jq2rS7XMWcPr3+sNGNssDqSnXj98hNE6iGs7Aeo=",
      "url": "_framework/System.Text.Json.9kdnbe9wt6.wasm"
    },
    {
      "hash": "sha256-eHH0KvehaAVpAuXvmvf5JdTtZtZZwHovuI6LzWG6IRw=",
      "url": "_framework/System.Text.RegularExpressions.41tmht37ji.wasm"
    },
    {
      "hash": "sha256-kZMBUb4JKTLmM0TBClrZcw1+qd58mqFp2DAKbce46ls=",
      "url": "_framework/System.Threading.7uzcwr4ylj.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-6jBYqhzcoclueiigYMwSzad8ntqy+63RIS1cy0+S6Mg=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-U+ondQsY1tgZA5dbboJK6eHiCmKTUAqD5TxQcuRweX8=",
      "url": "_framework/dotnet.native.3ojvhhahs9.wasm"
    },
    {
      "hash": "sha256-jzfJuXtQGKx7NujTmiXtkmM2OrrcByEiqhTqY2V8pU4=",
      "url": "_framework/dotnet.native.zragpt9n9o.js"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-0Y+28YV7GLEHY+Ed0CgY8Lb2NoVxMgKeZrS7ZhufEqE=",
      "url": "_framework/netstandard.xwjkegify0.wasm"
    },
    {
      "hash": "sha256-I1IlUlQX92BvD5ROqmddM5Cb3sPIaLw93OeEaZKd89w=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-h+MeTAfanGVq44yMdSS4FKREczLh9KUgCNAZiXa4svY=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
