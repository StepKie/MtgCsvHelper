self.assetsManifest = {
  "version": "WSmc/T4N",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-EXjYrIOnAHfZPed31o2EABDl13fqEzWGToCYoO1v60k=",
      "url": "_framework/Markdig.rtoxc0wwut.wasm"
    },
    {
      "hash": "sha256-No2xoQWfTCJ3fuGgQ4LGFjZ3y8RQDovdBcBWaiZoGjQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.2da364q11d.wasm"
    },
    {
      "hash": "sha256-3WJ1wzWRmFyKK0IRm2dUYvOM+OVPfOWsvkMowIuu+Rc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.zgc06ajws1.wasm"
    },
    {
      "hash": "sha256-tDYBzcQK5kh7DGPPQu3OV1Sn/hRcv8WFYQDwGt211F4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ofogrz7inn.wasm"
    },
    {
      "hash": "sha256-/ezEW3VJ3vJwHberNEoGgO/syy5HAlPWNqERoD9FABE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xz3fzmxw68.wasm"
    },
    {
      "hash": "sha256-uBgM308/HfhkVvX9OazyJlveCZGyJgRRHHJuQlmT5VE=",
      "url": "_framework/Microsoft.CSharp.wmooipvtvx.wasm"
    },
    {
      "hash": "sha256-37wHB/jlt93/ZOLjOd0siXKbtIoyo7J5j1UD4rSqGXU=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.lnxbcq1m3n.wasm"
    },
    {
      "hash": "sha256-YunNAKiB7YUM+iLhipQIbVkUyzqJSqxtgIAcilubJ4Q=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6nqa4c9e57.wasm"
    },
    {
      "hash": "sha256-CF+JUBJVrC4igJfWc0S6swocVEgyZ/Xw7xx7nlZZeHI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.o85mrs3iy3.wasm"
    },
    {
      "hash": "sha256-ZZHhwaRTOo1fWEENbHFWRLjFsI/jhFcwGxArzShOrf8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.5wijr4mjze.wasm"
    },
    {
      "hash": "sha256-T5+gxcDu6uOxNWXyoDqdgCfhQT0hFC9yEcvwyqbnI3I=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lb5nm0t9uu.wasm"
    },
    {
      "hash": "sha256-ie7Du9VQWtZPhOZA7/RimmldRHyrU1nO2dI34qewwmA=",
      "url": "_framework/Microsoft.Extensions.Configuration.hijfiv7l9d.wasm"
    },
    {
      "hash": "sha256-82wnsGGCWxkViFQWQU3oqP76NxfigUtefoozhlvXKQM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.flb1css1xx.wasm"
    },
    {
      "hash": "sha256-WfksFxwJLKukSCQfkpuns4o0/iIn3k1AOvoPyhwTdpI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.z1ypijpaqa.wasm"
    },
    {
      "hash": "sha256-dyjqOZrh0fL9qXtviAqzKuApsnl/SKAIMcg5Eusesac=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.pkiabcs8hj.wasm"
    },
    {
      "hash": "sha256-XI47H9CJpv1dbZ3fwzCfKY6NcHXNOxKQp/Wf5XoH3h8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.8p1r5e77qb.wasm"
    },
    {
      "hash": "sha256-ddMpWZ45rn58U7jvAnce1LoZe1ZuwsCk9E5BdZxEw+A=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.hpeobyote0.wasm"
    },
    {
      "hash": "sha256-id2rp/3V97tOedrVqIK7n9wi/Ku0kTvnd/4AhVz5Bqk=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.lxhfpbxc3z.wasm"
    },
    {
      "hash": "sha256-NO53RqQrMDOWJB0E320Qiq1IlEuThKVy37P1ogAPEU8=",
      "url": "_framework/Microsoft.Extensions.Http.k2bj7nvdmg.wasm"
    },
    {
      "hash": "sha256-5cfqPNIcfFg6iqfER7ZrH5/6ebzxRWC1GneHKx4RUZ0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.xt3qux73ci.wasm"
    },
    {
      "hash": "sha256-BHoKPKvt4ZdSuINrzeAPuA0oAaLw4KjfLMPmaWk24UI=",
      "url": "_framework/Microsoft.Extensions.Logging.c2b4pc8e7c.wasm"
    },
    {
      "hash": "sha256-sldxDyMtJXutT8+BNdqKJFLWUJGx3/u8AmwmTz71Bms=",
      "url": "_framework/Microsoft.Extensions.Options.2fb2i8t3vb.wasm"
    },
    {
      "hash": "sha256-dInZVUww20eJLEzVJbCrcH1CQHaRNfNt8YTAtXZwJJk=",
      "url": "_framework/Microsoft.Extensions.Primitives.wragkissu6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-CRM3xjoMVBK5MTDaU9xYmLR2QElURlK7MsNcegypPv0=",
      "url": "_framework/Microsoft.JSInterop.nkljd7l4yf.wasm"
    },
    {
      "hash": "sha256-HExlFL7izWPhtn6SC4jhbkY/1HZgcrz8xogo2FPJVf4=",
      "url": "_framework/MtgCsvHelper.4kdxpaliz2.wasm"
    },
    {
      "hash": "sha256-Bagb2Ir0gKz7yxHpNSfLeeV/PWvd4PoLpSI6LxUbkY8=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.z2l5u4nmd5.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-LJfyVf7lTG+hVOesZCCv/huYQb6a29TJ2d0wCS1Olls=",
      "url": "_framework/Serilog.4k4z78mm7g.wasm"
    },
    {
      "hash": "sha256-NHk6xRS3dIv7nLWuBUZvce3EXz7kvxiBsrjE7KvSMcI=",
      "url": "_framework/Serilog.Extensions.Logging.4aarm1ia2h.wasm"
    },
    {
      "hash": "sha256-kp2SCXz4fdsDb+fR+WFGpxe7oRlXLYbU5tSruqQUGHw=",
      "url": "_framework/Serilog.Settings.Configuration.aio2pf68g1.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-73wIvGUvSG26guYHLxP8lHc9GfnqCheNCfk45jNPPU8=",
      "url": "_framework/System.Collections.Concurrent.p2vrhj5qkh.wasm"
    },
    {
      "hash": "sha256-zvPKedFcbh8wc8dV+SP5PWsqDjX7Q5cHSqldp7I447I=",
      "url": "_framework/System.Collections.Immutable.2rgconsmz5.wasm"
    },
    {
      "hash": "sha256-v8dNk+drSrJjOzc5L0x5BQDLg7g7Aq86hf8I+s15iiA=",
      "url": "_framework/System.Collections.NonGeneric.jvlg1pd2if.wasm"
    },
    {
      "hash": "sha256-mWZqwTr297j5YG/nbOjWjBV8cjd+jTSRTT8AhuA3O9k=",
      "url": "_framework/System.Collections.Specialized.zpgr89ofi9.wasm"
    },
    {
      "hash": "sha256-ICJyN+89UrAYc6k65KZLbngOgVPblgTfzuJlsRE8wuk=",
      "url": "_framework/System.Collections.sdryj4ek0e.wasm"
    },
    {
      "hash": "sha256-jMNwvrt8bH8FrtGTYbRpjs+i0swozGlFjKqU5xRESiQ=",
      "url": "_framework/System.ComponentModel.Primitives.cgsqtl4nba.wasm"
    },
    {
      "hash": "sha256-5FKcJFNXwaEw0aZqTU5hghM05zAW6bQUBOHzDZ6kaN8=",
      "url": "_framework/System.ComponentModel.TypeConverter.0ln6mc5vzn.wasm"
    },
    {
      "hash": "sha256-CMFU+b1d2LT8JOuvrfe5QITMKX2d44sVccWUM8Kmno0=",
      "url": "_framework/System.ComponentModel.sbhdiphx0d.wasm"
    },
    {
      "hash": "sha256-SyuDxy2ipdSex5ezh8a71IKHXRZvw8waqvB69y/7Vvs=",
      "url": "_framework/System.Console.tav9mqde28.wasm"
    },
    {
      "hash": "sha256-13KcAADQzIV+Mt6tomnBy1N1fNoiFqhFzo+9vT02758=",
      "url": "_framework/System.Data.Common.vyvkwt6qs3.wasm"
    },
    {
      "hash": "sha256-VPeLnXUO0eH7dg9vFPfEOrHAX8AmtYm8twTpmbePrUg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.s4kz0yzfgf.wasm"
    },
    {
      "hash": "sha256-uWP/UaYyp/MTWqwc7NP76DKvA8n7ucS/9XU090RQRnE=",
      "url": "_framework/System.Diagnostics.TraceSource.hie92kyycg.wasm"
    },
    {
      "hash": "sha256-+P6iv9BqBaSzIMcl/QoNjmkXV39NyvncqPXZ1Ss7398=",
      "url": "_framework/System.Drawing.8wgi7x9zvd.wasm"
    },
    {
      "hash": "sha256-R8FQ8C5HETXzl5QrDjQHcKh2e7gl/ruIbeVUmGZAJTw=",
      "url": "_framework/System.Drawing.Primitives.dr6is8pck6.wasm"
    },
    {
      "hash": "sha256-TBkINe1dqJd6NZyVVZ/0OHYKv4Oy2XoWUPnxpY9LRPE=",
      "url": "_framework/System.IO.FileSystem.Watcher.07t2tzfeth.wasm"
    },
    {
      "hash": "sha256-sRfXsXtfMMTo2CLx4ZKDFwtkYvOe/IRL5Gwf4dsnXMk=",
      "url": "_framework/System.IO.MemoryMappedFiles.zn3zrwfe2r.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-hn4XXY+TwS7cyXYcERylg1SaYUPgZITu8XHvQVp6rbo=",
      "url": "_framework/System.Linq.Expressions.a89jcgsx5j.wasm"
    },
    {
      "hash": "sha256-w+M3EZQtIOKus41z5MpZjF12Ps7+l1vsb4rvTpkAwfE=",
      "url": "_framework/System.Linq.phco7w6edc.wasm"
    },
    {
      "hash": "sha256-oLRp33zeVPtvsRwIoczoGoNlHTs+QMYkGUbG+vtdypE=",
      "url": "_framework/System.Memory.kji3cubnvm.wasm"
    },
    {
      "hash": "sha256-as/f16YU3BGB80uQIR1i6cxPgVXfIQiW4uxTxLDUWtU=",
      "url": "_framework/System.Net.Http.u62e6yuf1i.wasm"
    },
    {
      "hash": "sha256-GcUZS2bRpGeEZCKIDbdSt4QSQyAwEiU5RtUDWnGUaOI=",
      "url": "_framework/System.Net.Primitives.vi4gsxomfn.wasm"
    },
    {
      "hash": "sha256-bW9ztWgEjTcY4MLg95rCvT/ViQjqHSvn1VBuiP1gSJU=",
      "url": "_framework/System.ObjectModel.1rebkrrbg6.wasm"
    },
    {
      "hash": "sha256-kICkvZIJClZepuNDn9jmIb678p19GhZyS//wleAza4E=",
      "url": "_framework/System.Private.CoreLib.go6nvw0s6c.wasm"
    },
    {
      "hash": "sha256-uaA4xSmveLZDnIeys5nK87rGzXtwxTH4bm/UffiOR4U=",
      "url": "_framework/System.Private.Uri.p0untnv3uc.wasm"
    },
    {
      "hash": "sha256-cTU5IVLwnjuKTbiXDlYnxL45i3JqpHntFsEAhgUx0wE=",
      "url": "_framework/System.Private.Xml.7mjt2knlwx.wasm"
    },
    {
      "hash": "sha256-7fxQRWMlzDZacsqgfD0kpxfG0yPKuBfZfB+7BnWcMh8=",
      "url": "_framework/System.Reflection.Metadata.xz62hrvms1.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-9aPqmfsBq57giPJV0U0WNFiu3KZ9vUmwqO4JNEcQ880=",
      "url": "_framework/System.Runtime.InteropServices.fj9jdecnpc.wasm"
    },
    {
      "hash": "sha256-H/2JewPKgK9YKJiB/yV3x41FjZOaJ2cfGbXroaI8Wgo=",
      "url": "_framework/System.Runtime.Numerics.r5t6872ec7.wasm"
    },
    {
      "hash": "sha256-QL20dcFrAe8H6bVc80jmevSsa8wV7wVzIE4H8KT8L7s=",
      "url": "_framework/System.Runtime.Serialization.Formatters.8maq9fo5j6.wasm"
    },
    {
      "hash": "sha256-MVD3ssIt7P+k4uq8Wp3WQbpOnJZhtGIWkQy1a7QrI3w=",
      "url": "_framework/System.Runtime.Serialization.Primitives.zfd78u3cjz.wasm"
    },
    {
      "hash": "sha256-TthxLU3ufJ/LQ/6UjpWqGNn9r9QX2+WlUeImam5PSqE=",
      "url": "_framework/System.Runtime.qqzfx55aid.wasm"
    },
    {
      "hash": "sha256-TrpzXmjVmPIIQ7U4RfyWxr8Pw4+apqfJKfaSWTJeFis=",
      "url": "_framework/System.Security.Cryptography.yfdtt5e6qc.wasm"
    },
    {
      "hash": "sha256-MFV1rWqnq/S/AtEdCoyvydacYIxU2Sajb1ETJ+dT8Bk=",
      "url": "_framework/System.Text.Encoding.Extensions.gwksaqyl68.wasm"
    },
    {
      "hash": "sha256-pq7ydT00u5UQm/avQFu31YBwr+Si5LyFKIzcQHmlJu8=",
      "url": "_framework/System.Text.Encodings.Web.i13tyue6z7.wasm"
    },
    {
      "hash": "sha256-3Ec1taMih8p4xZM6C+9XKgEmLBtKf0BH9mDnYniBMk4=",
      "url": "_framework/System.Text.Json.c8jebh28ka.wasm"
    },
    {
      "hash": "sha256-T1iE+oBebVQ4b5e0DmnMr9t8Po3b9JTp3S0LGke6/0o=",
      "url": "_framework/System.Text.RegularExpressions.3ffx0bcvdr.wasm"
    },
    {
      "hash": "sha256-GvMdTVO4I0q0PuZHsQZvBL96WOShdlyVATToJPc+OB4=",
      "url": "_framework/System.Threading.ui01g9g6lf.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-6qoyslveY9s5ZgXhuHLc3jYR+IbE2nDKuOJTIVWlVX0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-H9Uory8jxnEmczBDdT12kKh6g6GI/8U0HgCXyMxyce0=",
      "url": "_framework/dotnet.native.naaozygfm4.wasm"
    },
    {
      "hash": "sha256-EAl0oI3cxL35071DRH0g3CuZpH4IaBeWvmKCFAgMQHk=",
      "url": "_framework/dotnet.native.s9d3hsniln.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-7H/g1UWvoMjtl1Y8SssUmk3GiedNWjfkfa36KWXr8+A=",
      "url": "_framework/netstandard.gxyxd1k9mb.wasm"
    },
    {
      "hash": "sha256-EYu0hLA7keNiJKAQpgzDfBmPaUj5OpsdlnofpF2xzDY=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
