self.assetsManifest = {
  "version": "virhcY91",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-XrsZGktyAakARIo+IPOpkBODiKrhtyzTXNj2m8vj390=",
      "url": "_framework/Markdig.ato3fn3juu.wasm"
    },
    {
      "hash": "sha256-R3UyacfTB9T1xMHMIHVMMZI0RiaKB+4Ybg+j78m5Od4=",
      "url": "_framework/Microsoft.AspNetCore.Components.558eawuvxg.wasm"
    },
    {
      "hash": "sha256-bzs20GQ9q1Ifq0rmIahA3/p1rQM4SD/GV2ySfXZ7pCA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.jn6n69jo4d.wasm"
    },
    {
      "hash": "sha256-b7XFpEBpgrlbVV9emo4iQImzxH/zxafHhv2x1xc4LiA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7ym1nl260l.wasm"
    },
    {
      "hash": "sha256-fc/qVOlrICIbSyE3pjEsjaN6IxnleVzsdU4u2yst6Pc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xbtgn06cw3.wasm"
    },
    {
      "hash": "sha256-CBxp/l9KyKTy030y2/nWOnKZOfDTzDbpccnMMjxklcY=",
      "url": "_framework/Microsoft.CSharp.guffeeaqzt.wasm"
    },
    {
      "hash": "sha256-7BVGRhcVU4GB7OIz3iFUJ17OLSftAPZRZqLlfn9yMgA=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.8z6j4nkfuo.wasm"
    },
    {
      "hash": "sha256-1P+Zzl5D59KCH78flC4xITlVepQnZuZiSjNT64AruT0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.cwiycgimzh.wasm"
    },
    {
      "hash": "sha256-3gIRrSzp0H204Hux3PlvPIqChIrQWmh8qgfmerVuoXg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.6bhyx4eloy.wasm"
    },
    {
      "hash": "sha256-77Fnv68niEQGAt6FyYAD3YZ6oXOMn78t5VIl/cTWYBE=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.fcfhmtqd20.wasm"
    },
    {
      "hash": "sha256-aNjmAynmBFhQ7fUCsY+hf44Vmljlew/1O1s8Gv1ys9o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ogdd3gf9kw.wasm"
    },
    {
      "hash": "sha256-bQUv7kGhgDTmCIX9C1CwyDKH2/EflEg/YlSw0PkWHvE=",
      "url": "_framework/Microsoft.Extensions.Configuration.vxt8lztxtd.wasm"
    },
    {
      "hash": "sha256-Fyomf+MvKU+U0UJocL/QqQOa2hBFqGUTFR7ys7Qp5Oo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.94tiam18tx.wasm"
    },
    {
      "hash": "sha256-ViXZWP20lik6jz4YKNy9sGC9LVA+oVpRMqJ5eDc3saI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i12kadk469.wasm"
    },
    {
      "hash": "sha256-Y50HX3PQMJ4soEY3qF5l62/MIU7ySWSua6rOnJTS588=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.v9g0nhfssu.wasm"
    },
    {
      "hash": "sha256-ZHOdqgOueW9YoTx9IkCoa6+U4icIqB0V+w3S+jCI5xE=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.sa27s8rs4b.wasm"
    },
    {
      "hash": "sha256-u6WF/yNunpz7DfMc+hZBx/c2z54jJ+DLP9R9X7LHGHo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.931rgf7ct7.wasm"
    },
    {
      "hash": "sha256-bkkw3ba1G6KYCU63h/CnW9ZLcXk6DWvuucuT4VtMymI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.63qufu34wl.wasm"
    },
    {
      "hash": "sha256-mSTkUwaJW1rzV8XnxyTe2sR0d+be7DjzHDESqhb0y0I=",
      "url": "_framework/Microsoft.Extensions.Http.bvoe29ity8.wasm"
    },
    {
      "hash": "sha256-7he0KJcv7cGdqYeyRiqk2HHCpfbgPwMraaI+2uRi6ho=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.aed1u0pqfk.wasm"
    },
    {
      "hash": "sha256-C5hyh/s8qtXNfihhmY6W7WTXI0Eddvv1EbD7wB0zGNY=",
      "url": "_framework/Microsoft.Extensions.Logging.dageq1qagu.wasm"
    },
    {
      "hash": "sha256-TuHBVLLhoCufNP8rpAsJnV9JAn2Tk2glP3Ut2lrMvTM=",
      "url": "_framework/Microsoft.Extensions.Options.u9tmlj4p1y.wasm"
    },
    {
      "hash": "sha256-TKORY8CCoM+5MPgQyw9N1LGPA1oB5ItogkxMhUcNRlw=",
      "url": "_framework/Microsoft.Extensions.Primitives.cu7wxzg51n.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-OArFp/X9PJG6WAqU9vxfCRBMlTJyRmWkyBp7afAVD3Q=",
      "url": "_framework/Microsoft.JSInterop.kxhgfet8bu.wasm"
    },
    {
      "hash": "sha256-FIC6q3yZ6MyENiJKcrY+ijKHf08oEUofPi1UYMACRzs=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.s8fbmaux9v.wasm"
    },
    {
      "hash": "sha256-jCSQvyyPrwvE52jUcZsOlGcCTc+z/j1g8iLjM7KHyTQ=",
      "url": "_framework/MtgCsvHelper.g9iod74ak2.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-7Ph4DpIYUm6II3daX+GzmBUn++wgpMabIVkhba2X9FE=",
      "url": "_framework/Serilog.4s67d7c21i.wasm"
    },
    {
      "hash": "sha256-y4W0voy68MdBaTWWr+aKh2gJwf1766giLjnw5DdKsmY=",
      "url": "_framework/Serilog.Extensions.Logging.3ys5876a4v.wasm"
    },
    {
      "hash": "sha256-F3KAlF5HjvkTXwbLVn9fiSxSPwdZrsU3wEdEI3nsBo4=",
      "url": "_framework/Serilog.Settings.Configuration.vqprv27ecs.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-wv2hGo2k1yFggHr5SWGmXRTDUMi9lkcLZ8gvRu8uk94=",
      "url": "_framework/System.Collections.Concurrent.ex9iz6iw5e.wasm"
    },
    {
      "hash": "sha256-ONQQttASAm07FunL0Hm4Yd5hcnzP1yYGHOeoX3I5Kbo=",
      "url": "_framework/System.Collections.Immutable.s37xi0qpsd.wasm"
    },
    {
      "hash": "sha256-byMnXPen8ADUGiNQB/AxbigS+ykJsC887JZne7cCON4=",
      "url": "_framework/System.Collections.NonGeneric.dl1ikotx9m.wasm"
    },
    {
      "hash": "sha256-QFhWcivMrFE40qyZYAuMDn7/ExHd4hmKWis8cKsBORU=",
      "url": "_framework/System.Collections.Specialized.kv130zwjni.wasm"
    },
    {
      "hash": "sha256-9YUvgcSQQxXoNl09P/n3ELyJUv+Mc9s+cu/HFOtgm8I=",
      "url": "_framework/System.Collections.n9vr3wcer9.wasm"
    },
    {
      "hash": "sha256-hadqAT+t91rZHbWvPgk2tJgM1yU6hs++WPiVHZS9KVI=",
      "url": "_framework/System.ComponentModel.Primitives.75sk95zmyc.wasm"
    },
    {
      "hash": "sha256-kO1d5WHgGif/rtcp7+uCiUhbdI45oBvWYuAh+9zmbqE=",
      "url": "_framework/System.ComponentModel.TypeConverter.stw9cmabqo.wasm"
    },
    {
      "hash": "sha256-6BUaZyVWSY5ZZt9BQFsYp83+RSHWtwfYTxU/AwIAihk=",
      "url": "_framework/System.ComponentModel.wmvfk5w8xx.wasm"
    },
    {
      "hash": "sha256-ZqKpa/DiS3yDAmgrHomdpvmq/EPVPNm5clorfd9Vi0I=",
      "url": "_framework/System.Console.6t8gtonr90.wasm"
    },
    {
      "hash": "sha256-2H0nNlOgobIjQdkuQxCMclCbuH81DKMaldcaa0MwLpE=",
      "url": "_framework/System.Data.Common.45ut43xzc7.wasm"
    },
    {
      "hash": "sha256-iaYR1ilb/ptXxnCotz8NnvAp52tMvDVLrXoj1Gb/gZc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.psocmmn16b.wasm"
    },
    {
      "hash": "sha256-NvAekc8k89yOgVtIgkYnnhaoo6Hm+FM77I3FWkGSZqU=",
      "url": "_framework/System.Diagnostics.TraceSource.y2idjc91nt.wasm"
    },
    {
      "hash": "sha256-HiBgNUM2VNbuqPKIsk73vEhLrb51jUGwGjuvzH91+Gw=",
      "url": "_framework/System.Drawing.6fcsuhr9fw.wasm"
    },
    {
      "hash": "sha256-LnpRgobWIDnOIBc+ICh37MyZ7xdEsD2HsrJXrtvIDSo=",
      "url": "_framework/System.Drawing.Primitives.28za93etgk.wasm"
    },
    {
      "hash": "sha256-v42+EIAtV/ZkPctnzt55ZEFMeLYL/8tqs5BGW2y6vJU=",
      "url": "_framework/System.IO.FileSystem.Watcher.jnnklxo8fz.wasm"
    },
    {
      "hash": "sha256-KN9fkqlrZAgJAml42Dr7HqS8DGk4pNlbqWpRYG7048E=",
      "url": "_framework/System.IO.MemoryMappedFiles.o87ymcoymw.wasm"
    },
    {
      "hash": "sha256-nGjUaVHyjfc2K1Rjam+1nMQpdp8fmTKJBcmoV6TXfkk=",
      "url": "_framework/System.IO.Pipelines.gvnbjefpez.wasm"
    },
    {
      "hash": "sha256-cT6t4P4PejQiskJ4OOq0SF9DwAQJAWAupk1QX1XcXy0=",
      "url": "_framework/System.Linq.Expressions.t52qd9ckoh.wasm"
    },
    {
      "hash": "sha256-oRacayt6Mmffab1TcW6iEawNxciPCuphy/Z3amEO5LY=",
      "url": "_framework/System.Linq.vc1urfv8qz.wasm"
    },
    {
      "hash": "sha256-1DHiZ996Hrf7CbhJlJpnpA0/+37UxBGtZYvU2kfJsSU=",
      "url": "_framework/System.Memory.odwxwzetpx.wasm"
    },
    {
      "hash": "sha256-mhyM0VemMVPaDN+QQJuZMFllKb7iMGLTbTvOF/JtQ/c=",
      "url": "_framework/System.Net.Http.y9oaiynnb6.wasm"
    },
    {
      "hash": "sha256-LSADAFAr0rBPzaiu6W7bKzV63Ul8NeQ/N1wCVpdzgdI=",
      "url": "_framework/System.Net.Primitives.5yixy8k25o.wasm"
    },
    {
      "hash": "sha256-x5V+JFIRzElcO7z7tuyOvAXgexaKd2lRSv3bs5JAAJA=",
      "url": "_framework/System.ObjectModel.fu4plnkaaa.wasm"
    },
    {
      "hash": "sha256-+wKre5/CEk+0DavL8h0Gz+LH+Sb1/sLM7Ik1VFtAZt8=",
      "url": "_framework/System.Private.CoreLib.9359b8nw17.wasm"
    },
    {
      "hash": "sha256-KSX8a7+RE0EotIUg5kaZ2+6aQRmaSMfd6FVStQ+5ikM=",
      "url": "_framework/System.Private.Uri.xe5vw2p8e5.wasm"
    },
    {
      "hash": "sha256-XN9VMRsQAG4UrA8Eu/8m2w+0amIf/IGCHrHMCi8Wy+o=",
      "url": "_framework/System.Private.Xml.gzm4q2v8mq.wasm"
    },
    {
      "hash": "sha256-opkfqQCTJW0J3c8R3JHavaj1QhiFjUrDhRYpYfZfm9o=",
      "url": "_framework/System.Reflection.Metadata.y8emoo7brm.wasm"
    },
    {
      "hash": "sha256-/AffZDeH/B6zoM1CSAWxii9f6mlQXwYIAPcGD9lv5H0=",
      "url": "_framework/System.Runtime.40oq8dmt2b.wasm"
    },
    {
      "hash": "sha256-uZE+RghUGhFEtBSdz2haiMPXM+YHKxDYln/S/wJd1b0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.tnarnfpqjk.wasm"
    },
    {
      "hash": "sha256-bizWMFoLLOTWgj1fuqm9ZXWDIwyAZSIm4WrQQT5SvOs=",
      "url": "_framework/System.Runtime.InteropServices.u5cospuobf.wasm"
    },
    {
      "hash": "sha256-7Cu827slqgbqeOqZt7ZhMOUkdMpHIEetKsMw/J4dXnU=",
      "url": "_framework/System.Runtime.Numerics.ghu3bj0k08.wasm"
    },
    {
      "hash": "sha256-8b/xmleWdhAlzevWhrctyNcLu5yqTHIB+xpWA+EUE6w=",
      "url": "_framework/System.Runtime.Serialization.Formatters.5bq77i9nuv.wasm"
    },
    {
      "hash": "sha256-MdA9YiWV4xcZpiXLFgShaXrLzdzcwwFG3U+szTsL5Ks=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ddl08jz85k.wasm"
    },
    {
      "hash": "sha256-aFJbeaZvut5sAnubagtP8jC3o7bzmyQ3HBWZxWYzCsY=",
      "url": "_framework/System.Security.Cryptography.owdct9c3kq.wasm"
    },
    {
      "hash": "sha256-ynSEOnthJaZ37HfcAPf7jUnBXJb3qErEQfrIY5AWXkE=",
      "url": "_framework/System.Text.Encoding.Extensions.6p4g1eeibv.wasm"
    },
    {
      "hash": "sha256-1Sr3NN1aQOE+1F8G3kwzVbHdwDRQg0a4RktpKJRmuls=",
      "url": "_framework/System.Text.Encodings.Web.pnw29cwzej.wasm"
    },
    {
      "hash": "sha256-IL/7PD9DlvSDDQekJwjuQOmXnmUKTQgKosQNBj03P+w=",
      "url": "_framework/System.Text.Json.oqmzbqlo69.wasm"
    },
    {
      "hash": "sha256-3bZNo2G7SaqKKV8hBe0CHgOBCcD/rOa5bUU2VxDyN+s=",
      "url": "_framework/System.Text.RegularExpressions.j0570dmeou.wasm"
    },
    {
      "hash": "sha256-/JSuSC4BUrM4LBwRzEmrP5+r6UkHFBf9uBxZYPZWwls=",
      "url": "_framework/System.Threading.w7ybriposy.wasm"
    },
    {
      "hash": "sha256-319B7WIXJ7ZD6SZ1l7es3CoglOLgv5lKWx0Ew9mli1c=",
      "url": "_framework/System.f0t8bkq7p2.wasm"
    },
    {
      "hash": "sha256-NkqEQXIVmK0hxe8F43mkOfRZDK48CYGi5cwjg4+h0o8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5A57FxzcJRwpIrn/eN+NeAKcVHW08gXRk0i0BDM4TDE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-oksVqHEW5dic8ULICrYkuUVNascZfAw7ZPMG45TR/ak=",
      "url": "_framework/dotnet.native.6m0hb3g78a.js"
    },
    {
      "hash": "sha256-o2x4vkXl29AT7+ydjSBFXzuxrlVCqlbu0dnKYeMk3RM=",
      "url": "_framework/dotnet.native.zw8ib5pvmp.wasm"
    },
    {
      "hash": "sha256-W1NVCHdXLsZwmcxPLLatkJOSnfn1UNne6uSpSi63ozM=",
      "url": "_framework/dotnet.runtime.7laf4z0i7i.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-WxCpPOEzpE2HZsjDvA0o4cju/uNEC/fAcS36KN6SSps=",
      "url": "_framework/netstandard.xp8irinc9y.wasm"
    },
    {
      "hash": "sha256-EYu0hLA7keNiJKAQpgzDfBmPaUj5OpsdlnofpF2xzDY=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
