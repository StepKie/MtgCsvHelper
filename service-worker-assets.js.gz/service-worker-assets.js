self.assetsManifest = {
  "version": "HSV4LPL2",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-0SgJ0gzgRHGpGV9Und07mw3VK77JmcqHKNEO4BZ3T+k=",
      "url": "_framework/Microsoft.CSharp.r1zfg22c7j.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-d8syCONgAG+AKMXSWS/1/dCVO9Rr2TGOJRDaxzuxfa8=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.dbr9mfdc87.wasm"
    },
    {
      "hash": "sha256-f4GU3nnUL+eEBrPyIUcX3hg++lms8szkYtYIog2odHI=",
      "url": "_framework/MtgCsvHelper.xkx2wqejny.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-+/3A4lrXGyV1SI30Q8J0ONqqPp8Xhc5WJ4ABmiKHtpQ=",
      "url": "_framework/Serilog.v3jtg2iuay.wasm"
    },
    {
      "hash": "sha256-eYOMTzNiLYnpqEayX8IVT2Kt7qPGyVgJRI1GyDoDBt8=",
      "url": "_framework/System.Collections.Concurrent.7sllbotgae.wasm"
    },
    {
      "hash": "sha256-VTFzPh+BU74gWT3i29EAaE3QkIz34qwKpg32qwiTdIw=",
      "url": "_framework/System.Collections.Immutable.tmikab8rui.wasm"
    },
    {
      "hash": "sha256-1vn+pSBm0DQON+1k0BxuUwwmWOfZiPujFdA9NF1JvUA=",
      "url": "_framework/System.Collections.NonGeneric.ih6k4an5ec.wasm"
    },
    {
      "hash": "sha256-fvlyK4BQc6LWFrbgnjyZd0hyA8B2J8lJvHnOqceyUuM=",
      "url": "_framework/System.Collections.Specialized.6fu243pkbp.wasm"
    },
    {
      "hash": "sha256-mTFyJiuE/BK9+fpqNIfade7cB073ZOfg/97tT/eQ5Kc=",
      "url": "_framework/System.Collections.fa33ro05xw.wasm"
    },
    {
      "hash": "sha256-iVp95hof2yFGtYs2Sp6ByRNNXn6GRFgvnTwAuIhbR8o=",
      "url": "_framework/System.ComponentModel.Annotations.1m3x69482j.wasm"
    },
    {
      "hash": "sha256-xc2qLtM2Jy639jEwGzVZBaeGGe8kccJygSe3d4nLidg=",
      "url": "_framework/System.ComponentModel.Primitives.zitvf7ag1u.wasm"
    },
    {
      "hash": "sha256-IUtI5X0V5tmQIzVqOMutpVF7d32yvWMqBGsWmUrgTqk=",
      "url": "_framework/System.ComponentModel.TypeConverter.7an8dkdva6.wasm"
    },
    {
      "hash": "sha256-WmtAQESEnRlgy6cf9wq9Ara3dePY6YSWe+uFuPESbrY=",
      "url": "_framework/System.ComponentModel.ejevkr3409.wasm"
    },
    {
      "hash": "sha256-Pj7CsjW1gNFwZWFjpP1F93L9lmNzxlNBL200w07MOFE=",
      "url": "_framework/System.Console.6y3x4aso2n.wasm"
    },
    {
      "hash": "sha256-O8mO65GdNgJ0ssFyOb3XtkWL8zM1oSqfEBvi/w+zBMA=",
      "url": "_framework/System.Data.Common.j6de7e38pt.wasm"
    },
    {
      "hash": "sha256-cjaDxxsy/mQDwqF43JVDXPnHNHlcwRTkHy8J0r6/PqE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ed9olzpvdl.wasm"
    },
    {
      "hash": "sha256-ZHpJ/hGKt0ZJBGfeybogD8nrdVh4HKlMXXTq5QUjzGw=",
      "url": "_framework/System.Diagnostics.TraceSource.4wu4pn9ob6.wasm"
    },
    {
      "hash": "sha256-T/Cgc1lOB9RDMZO7Wy+1G4EQIcWPUmXHz3NkL/vYaTg=",
      "url": "_framework/System.Drawing.Primitives.rh13azpeuv.wasm"
    },
    {
      "hash": "sha256-0e2aBibUB23f9KpiyrADoRVC5LGftAaBzjSFQ4jfIro=",
      "url": "_framework/System.Drawing.fguc99srv0.wasm"
    },
    {
      "hash": "sha256-5+liLiLd6jWgkEG2xM/aojBHyKGdHvbhAvnht42F434=",
      "url": "_framework/System.IO.Compression.5pd3qhz9wr.wasm"
    },
    {
      "hash": "sha256-2Jp08rYOO5Kg/KlONbfYTQRdxjIry4VrquoeU3Q/ElI=",
      "url": "_framework/System.IO.MemoryMappedFiles.8020zmsqwe.wasm"
    },
    {
      "hash": "sha256-sZPm2aGLNOc9pfymsvDq47UHAxqORuQbJh6GJUWPWfk=",
      "url": "_framework/System.IO.Pipelines.5f5djt3eph.wasm"
    },
    {
      "hash": "sha256-ozI6Cvkx2BHr23YSz+7+U6kMqqAnlsDCLxZepgxydKk=",
      "url": "_framework/System.Linq.Expressions.d8vt2ulzrh.wasm"
    },
    {
      "hash": "sha256-emeNfdXzCaNc8+zLlFVD/jYmLiaPnGt56le156Hvby8=",
      "url": "_framework/System.Linq.ezoceon704.wasm"
    },
    {
      "hash": "sha256-SfccooN4qa28fSPcPfyu5xMqpXzGq7xF7JXdFrnQQTU=",
      "url": "_framework/System.Memory.rna3s95sdv.wasm"
    },
    {
      "hash": "sha256-UwnLeJf9nNH4B2Gm7G1OguyEIh3ZbCACwy3Nnq5vXzQ=",
      "url": "_framework/System.Net.Http.xrw7hh4yyx.wasm"
    },
    {
      "hash": "sha256-IPIw9+jujeSDp0FZzWYrhFisz2QgzP5hFlZQLfQPaxQ=",
      "url": "_framework/System.Net.Primitives.sxe1s0bbe8.wasm"
    },
    {
      "hash": "sha256-J6G/91AYSkc9uo6+twOlsU5dqPy3DsQlAJnnJFBHU6k=",
      "url": "_framework/System.ObjectModel.31c1eweu5s.wasm"
    },
    {
      "hash": "sha256-03KO+F+lwwj322j8v5UKK8zkU7vNJY1MAf9e0bSupzE=",
      "url": "_framework/System.Private.CoreLib.1v9d6tohyr.wasm"
    },
    {
      "hash": "sha256-IHVBewWKfO13mvSTyTIz6HA7zDLaxOSvbGZdI1Q5rzo=",
      "url": "_framework/System.Private.Uri.0srqab9yxv.wasm"
    },
    {
      "hash": "sha256-ygt16qbLKcLnI04hK8XN097jDenvUDTybZ9KppC4/HY=",
      "url": "_framework/System.Private.Xml.6opd18j9c2.wasm"
    },
    {
      "hash": "sha256-3T3foKG4QFU+drV9Oi4Co/F4+9rNAa4ERbCywQCvjTw=",
      "url": "_framework/System.Reflection.Metadata.xzpdldrlbd.wasm"
    },
    {
      "hash": "sha256-Fww1hLJpAF3KullOuLXENGdD3XTp0oP7oDq54FccaAk=",
      "url": "_framework/System.Runtime.1qkcsd5v54.wasm"
    },
    {
      "hash": "sha256-tIJ8pn9PM7XcJdTDpXq+c1Xfu0QLAyLC+502dBLFQLI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.coecs3uxvt.wasm"
    },
    {
      "hash": "sha256-mFgg+qcpzec/UPCag2xkzpzp5RQwaPGVCXYpSyyECBw=",
      "url": "_framework/System.Runtime.InteropServices.kdrgmxrrq0.wasm"
    },
    {
      "hash": "sha256-W8kWnVpBxos+vsBR3IOH1PufMNFiFhWpF2NBjZ0Z/XQ=",
      "url": "_framework/System.Runtime.Numerics.npg7xi7buw.wasm"
    },
    {
      "hash": "sha256-GcLSww2Bm5IBm8JCJVBfYVbISiHJkdOBiW6S66slSe0=",
      "url": "_framework/System.Runtime.Serialization.Formatters.9gtor7616t.wasm"
    },
    {
      "hash": "sha256-LaLryg6jz+Eg1ZygxkN3UgCktQcNZE9idrqPZdZRyUo=",
      "url": "_framework/System.Security.Cryptography.138x71f0ov.wasm"
    },
    {
      "hash": "sha256-bQwr0yZ2Vy+E57aGNk84lo2p2tH+APqeqqQ0ZmhIEi4=",
      "url": "_framework/System.Text.Encoding.Extensions.zswydz4t9a.wasm"
    },
    {
      "hash": "sha256-D+pBbJjnKp9PL8KbrSUvUO/6WjAH+rhjWv+lnvirZSc=",
      "url": "_framework/System.Text.Encodings.Web.bhefru8hxq.wasm"
    },
    {
      "hash": "sha256-1/W65w5pSidqDx2nQ3b8ry72D7swUbbOwknb+ahN//E=",
      "url": "_framework/System.Text.Json.rvu609di2o.wasm"
    },
    {
      "hash": "sha256-z6sn+ZTF4roWGJHzLQGjNoovsvzSunWLrU8fnx/Jtdc=",
      "url": "_framework/System.Text.RegularExpressions.zvlo3lhrlt.wasm"
    },
    {
      "hash": "sha256-7fOEaxcVAGqKZUUFB2VgYOrWmwJMXiyWEKizkrP0lg8=",
      "url": "_framework/System.Threading.bmb1j6l0bv.wasm"
    },
    {
      "hash": "sha256-GBsoWgsm7nTRKlb5Lr430r1XsgW1gVH+jeoGAIS2K00=",
      "url": "_framework/System.cvgusyd4es.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-CaQCNxc1XOxYvUULABGvXKtKzXSeVtcD73+9oeLE9Jk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-XFLcIY8rPC/mqM3RJIPUN6gqj9oI5W/WvOHDW9IFJYc=",
      "url": "_framework/dotnet.native.k01ayqow37.wasm"
    },
    {
      "hash": "sha256-ocHe8wHnP2Hwa08/oovaNp1/hSt+sSh155sXHMgdGFk=",
      "url": "_framework/dotnet.native.zbzuw4wy2l.js"
    },
    {
      "hash": "sha256-SOUHEQ3FhDAibBSR2u90NWZpoBjPuWRmH0BAATUlhJU=",
      "url": "_framework/dotnet.runtime.web2r9gqbh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-5ipVlSrAjnuem7F//tqWSxq/xiJNUv9uB/TQhzKJHXY=",
      "url": "_framework/netstandard.q8e8jyywo1.wasm"
    },
    {
      "hash": "sha256-I1IlUlQX92BvD5ROqmddM5Cb3sPIaLw93OeEaZKd89w=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-TmBD2a0LrE5jr00vv6yIOkqjCCPlr0YMHoj8XEFF140=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
