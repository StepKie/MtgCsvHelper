self.assetsManifest = {
  "version": "8M6haMRK",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-XrsZGktyAakARIo+IPOpkBODiKrhtyzTXNj2m8vj390=",
      "url": "_framework/Markdig.ato3fn3juu.wasm"
    },
    {
      "hash": "sha256-R3UyacfTB9T1xMHMIHVMMZI0RiaKB+4Ybg+j78m5Od4=",
      "url": "_framework/Microsoft.AspNetCore.Components.558eawuvxg.wasm"
    },
    {
      "hash": "sha256-bzs20GQ9q1Ifq0rmIahA3/p1rQM4SD/GV2ySfXZ7pCA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.jn6n69jo4d.wasm"
    },
    {
      "hash": "sha256-b7XFpEBpgrlbVV9emo4iQImzxH/zxafHhv2x1xc4LiA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7ym1nl260l.wasm"
    },
    {
      "hash": "sha256-fc/qVOlrICIbSyE3pjEsjaN6IxnleVzsdU4u2yst6Pc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xbtgn06cw3.wasm"
    },
    {
      "hash": "sha256-YsMBAYn9XCqdKhZ5JO2/XHcFPfdP4wH6r+nLGzlaOOk=",
      "url": "_framework/Microsoft.CSharp.ijahts0vrn.wasm"
    },
    {
      "hash": "sha256-7BVGRhcVU4GB7OIz3iFUJ17OLSftAPZRZqLlfn9yMgA=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.8z6j4nkfuo.wasm"
    },
    {
      "hash": "sha256-1P+Zzl5D59KCH78flC4xITlVepQnZuZiSjNT64AruT0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.cwiycgimzh.wasm"
    },
    {
      "hash": "sha256-3gIRrSzp0H204Hux3PlvPIqChIrQWmh8qgfmerVuoXg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.6bhyx4eloy.wasm"
    },
    {
      "hash": "sha256-77Fnv68niEQGAt6FyYAD3YZ6oXOMn78t5VIl/cTWYBE=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.fcfhmtqd20.wasm"
    },
    {
      "hash": "sha256-aNjmAynmBFhQ7fUCsY+hf44Vmljlew/1O1s8Gv1ys9o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ogdd3gf9kw.wasm"
    },
    {
      "hash": "sha256-bQUv7kGhgDTmCIX9C1CwyDKH2/EflEg/YlSw0PkWHvE=",
      "url": "_framework/Microsoft.Extensions.Configuration.vxt8lztxtd.wasm"
    },
    {
      "hash": "sha256-Fyomf+MvKU+U0UJocL/QqQOa2hBFqGUTFR7ys7Qp5Oo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.94tiam18tx.wasm"
    },
    {
      "hash": "sha256-ViXZWP20lik6jz4YKNy9sGC9LVA+oVpRMqJ5eDc3saI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i12kadk469.wasm"
    },
    {
      "hash": "sha256-Y50HX3PQMJ4soEY3qF5l62/MIU7ySWSua6rOnJTS588=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.v9g0nhfssu.wasm"
    },
    {
      "hash": "sha256-ZHOdqgOueW9YoTx9IkCoa6+U4icIqB0V+w3S+jCI5xE=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.sa27s8rs4b.wasm"
    },
    {
      "hash": "sha256-u6WF/yNunpz7DfMc+hZBx/c2z54jJ+DLP9R9X7LHGHo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.931rgf7ct7.wasm"
    },
    {
      "hash": "sha256-bkkw3ba1G6KYCU63h/CnW9ZLcXk6DWvuucuT4VtMymI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.63qufu34wl.wasm"
    },
    {
      "hash": "sha256-mSTkUwaJW1rzV8XnxyTe2sR0d+be7DjzHDESqhb0y0I=",
      "url": "_framework/Microsoft.Extensions.Http.bvoe29ity8.wasm"
    },
    {
      "hash": "sha256-7he0KJcv7cGdqYeyRiqk2HHCpfbgPwMraaI+2uRi6ho=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.aed1u0pqfk.wasm"
    },
    {
      "hash": "sha256-C5hyh/s8qtXNfihhmY6W7WTXI0Eddvv1EbD7wB0zGNY=",
      "url": "_framework/Microsoft.Extensions.Logging.dageq1qagu.wasm"
    },
    {
      "hash": "sha256-TuHBVLLhoCufNP8rpAsJnV9JAn2Tk2glP3Ut2lrMvTM=",
      "url": "_framework/Microsoft.Extensions.Options.u9tmlj4p1y.wasm"
    },
    {
      "hash": "sha256-TKORY8CCoM+5MPgQyw9N1LGPA1oB5ItogkxMhUcNRlw=",
      "url": "_framework/Microsoft.Extensions.Primitives.cu7wxzg51n.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-OArFp/X9PJG6WAqU9vxfCRBMlTJyRmWkyBp7afAVD3Q=",
      "url": "_framework/Microsoft.JSInterop.kxhgfet8bu.wasm"
    },
    {
      "hash": "sha256-zA/t3YfaSGwGHgmn7h6P2TzU6MJbOeVZ2BLYfFIneZk=",
      "url": "_framework/MtgCsvHelper.4mj6fmaxxg.wasm"
    },
    {
      "hash": "sha256-cCfaYAscJUPOVz2N0k4/w+4dk5SPEegRlvHxRdSvtjs=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.cdfzc1rrj5.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-7Ph4DpIYUm6II3daX+GzmBUn++wgpMabIVkhba2X9FE=",
      "url": "_framework/Serilog.4s67d7c21i.wasm"
    },
    {
      "hash": "sha256-y4W0voy68MdBaTWWr+aKh2gJwf1766giLjnw5DdKsmY=",
      "url": "_framework/Serilog.Extensions.Logging.3ys5876a4v.wasm"
    },
    {
      "hash": "sha256-F3KAlF5HjvkTXwbLVn9fiSxSPwdZrsU3wEdEI3nsBo4=",
      "url": "_framework/Serilog.Settings.Configuration.vqprv27ecs.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-bx0qMNHqRJ5GT2MGKwyALroLlERn17dH4W9z0EYWl0E=",
      "url": "_framework/System.Collections.3ba1j8mb9j.wasm"
    },
    {
      "hash": "sha256-gQqLAbpykZp+U/OD2qCyJjnfMoL7StokeRMwY7fXDEM=",
      "url": "_framework/System.Collections.Concurrent.hox4780oxe.wasm"
    },
    {
      "hash": "sha256-x6Gg9UzL6UrPcKLl9gTrtfaAA7zLDnPuGyWr4elAJ/s=",
      "url": "_framework/System.Collections.Immutable.lpiqtwkmun.wasm"
    },
    {
      "hash": "sha256-W8QnJwK2XRbxlX2O1Lpu+oCbcfGq/2b0jwYkysoImEo=",
      "url": "_framework/System.Collections.NonGeneric.tywjuo17j1.wasm"
    },
    {
      "hash": "sha256-3n7RoWM2WD9xOUEsWrWCuey47f90dFs52XihW2CwiiU=",
      "url": "_framework/System.Collections.Specialized.y3tecmpnpg.wasm"
    },
    {
      "hash": "sha256-LMVQ7cWkbPhnZDln8dAJZKAgyzNQoCvYtn0raPTqaEE=",
      "url": "_framework/System.ComponentModel.42apeugn08.wasm"
    },
    {
      "hash": "sha256-VnFhF4XVjWlU605/0gV0tsLW/Z465JEH5xUka+5furw=",
      "url": "_framework/System.ComponentModel.Primitives.2p1f3avut1.wasm"
    },
    {
      "hash": "sha256-bQ/CtXwZuOCOLlstd0RgaKgI3BrExomNolAudhnoSDI=",
      "url": "_framework/System.ComponentModel.TypeConverter.3sa8gi709j.wasm"
    },
    {
      "hash": "sha256-Km4wDPxTX13fDqYN2/q1I9eoYfMMLxWjxfY5CL+4MZ8=",
      "url": "_framework/System.Console.ip8fgak4im.wasm"
    },
    {
      "hash": "sha256-ZSJ9tXHUcmKdHFwgdaVsJ7T+1jQeDQVBzqTpkM2VCEs=",
      "url": "_framework/System.Data.Common.rwwohc0vsa.wasm"
    },
    {
      "hash": "sha256-cPxJAiazG3gNxWdx6Nr4RFm6ODjjjO50dWgA6vZHZoY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0ot966mc38.wasm"
    },
    {
      "hash": "sha256-VxqTBz/7fflT+F++oQpG3omNJ5dc5bSA/WdsHDkj3Wk=",
      "url": "_framework/System.Diagnostics.TraceSource.fqq46du70h.wasm"
    },
    {
      "hash": "sha256-UCF+CmBaAPNhpTEk8EubCBgPthVdPGu32jP2GUSzYiE=",
      "url": "_framework/System.Drawing.Primitives.gc55zpfe60.wasm"
    },
    {
      "hash": "sha256-BQVqh10/miWXV7ylhdX3h4ZFbA4z4gInC/Q797FWiVA=",
      "url": "_framework/System.Drawing.ndt5n06kpt.wasm"
    },
    {
      "hash": "sha256-wdOWz4N8xI98827evR3VDJdExzobWbT3u+CTwz+b2/E=",
      "url": "_framework/System.IO.FileSystem.Watcher.lz85rzbsqr.wasm"
    },
    {
      "hash": "sha256-RZEb1BybSwgJfIiIJuJo+4pn3fTDzThR4QSOpdVUwMU=",
      "url": "_framework/System.IO.MemoryMappedFiles.5wg31ec3vz.wasm"
    },
    {
      "hash": "sha256-LHmn3NZ0cYl/sD4s/EA26iSAYqDCycxgYdwt6suIKLM=",
      "url": "_framework/System.IO.Pipelines.wfn2m8uvna.wasm"
    },
    {
      "hash": "sha256-MCW/lTAZ0Mq/w1BmeZ7OTYm0tLZ/x75LbABhVwredTU=",
      "url": "_framework/System.Linq.Expressions.0k82zc5di6.wasm"
    },
    {
      "hash": "sha256-qZS74R5g3VA30OyvRXi373LI6hw57g3u4T/Ag8MqQco=",
      "url": "_framework/System.Linq.hmgqapv2r5.wasm"
    },
    {
      "hash": "sha256-nrtDk38ymV76zVq1y6ZJsylV8/lnTqWpWMjRsTjFfMY=",
      "url": "_framework/System.Memory.m7pn9n86ux.wasm"
    },
    {
      "hash": "sha256-FoCmmeSoCmGRc2zBKhv+6imTtx8W5F5z6w2YInTthwM=",
      "url": "_framework/System.Net.Http.6t1f1ez0dp.wasm"
    },
    {
      "hash": "sha256-UWz8Xc3aMOOTtjyxXS9iphkcGf6l5buhiMUj+mgIxRU=",
      "url": "_framework/System.Net.Primitives.neyihtxzev.wasm"
    },
    {
      "hash": "sha256-SvvnzqljzcVrnOv94TRvNCKfSjojAyM9q2URiEsIEjI=",
      "url": "_framework/System.ObjectModel.i6q3g55zc3.wasm"
    },
    {
      "hash": "sha256-mOuK0vcNxHUJlGpRz4Nj+5G2UG2dTVg5nukRYodYYBs=",
      "url": "_framework/System.Private.CoreLib.oclyjqbw1i.wasm"
    },
    {
      "hash": "sha256-EHNmGTpNL94hAEPNWVO0nqqoh41lEF4dwYunxMR82Cw=",
      "url": "_framework/System.Private.Uri.k7wkn3zsss.wasm"
    },
    {
      "hash": "sha256-WBkxFtorWnf9bMHh9sXYA2t4S4CO5JokDaH/1teGIBk=",
      "url": "_framework/System.Private.Xml.o8j5m49cqw.wasm"
    },
    {
      "hash": "sha256-mF1BHe2zHhP30woEyylHHZXTPahQYNl8mrde2aMXC+U=",
      "url": "_framework/System.Reflection.Metadata.os6c15ehio.wasm"
    },
    {
      "hash": "sha256-P8lAAVwooNX4VhfAatDrT2nE0EKZIfk7/uH9Qi7sw8s=",
      "url": "_framework/System.Runtime.5703bubt5v.wasm"
    },
    {
      "hash": "sha256-T54x5qF3hoAItx5TYSPqQLnMPsXJpDo/PQWRHXi3qU8=",
      "url": "_framework/System.Runtime.InteropServices.7ikm9lz5x5.wasm"
    },
    {
      "hash": "sha256-cTDlU0sLp3hCmTKUK2AVqrlAjuFjQveVBhCUZiIdUkc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lnedh9fxsl.wasm"
    },
    {
      "hash": "sha256-BJDsWKEQQmzd8RSXTb8T23vrw65/GaDp6HlRu9hGssg=",
      "url": "_framework/System.Runtime.Numerics.sowebyam11.wasm"
    },
    {
      "hash": "sha256-Ec59e8Cw9v7F+rz2aVEmcYFQTPsQp0wCCNuxz+UGzeg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.jbhpivmuy0.wasm"
    },
    {
      "hash": "sha256-JglRMh8993SiSt5YUvOBMzKRb/DGgA5GbJGBT9c2RQk=",
      "url": "_framework/System.Runtime.Serialization.Primitives.a01j3ygjje.wasm"
    },
    {
      "hash": "sha256-a+R4kre/cGJSIHs+4gglHdZFHO/v+XNAz0BqWOS8G7g=",
      "url": "_framework/System.Security.Cryptography.vjqowebul2.wasm"
    },
    {
      "hash": "sha256-j+zCps/oNSk5OV72cfSlTBJkRGj5v7WnunZTKbQU1Bs=",
      "url": "_framework/System.Text.Encoding.Extensions.rlgq68v5ve.wasm"
    },
    {
      "hash": "sha256-5roL5hgDxtpOyji6xusmx3evKf+54YuFbIJpejfq0XQ=",
      "url": "_framework/System.Text.Encodings.Web.q7l6i2z1r3.wasm"
    },
    {
      "hash": "sha256-awoBdF0HJanweIej0Lh4jEBD8Ghjklu7Lv0HJGn5v3E=",
      "url": "_framework/System.Text.Json.da6v40cqzm.wasm"
    },
    {
      "hash": "sha256-Z3sQiHXurooJQltUpyrnP32n3JyLM+QUbfNov/R4Aq4=",
      "url": "_framework/System.Text.RegularExpressions.v6vi91cc6r.wasm"
    },
    {
      "hash": "sha256-DZNYN66w4Cxvq13U24XRHTuREyYhUxfyAaO6ZqHcS3w=",
      "url": "_framework/System.Threading.le8i4li69q.wasm"
    },
    {
      "hash": "sha256-/Imz/Enqa2AZc4T3k/CqtsM6674KRN9OUtvK4Nokhew=",
      "url": "_framework/System.wznexm8bk2.wasm"
    },
    {
      "hash": "sha256-JeCue0ZaZleIqK2QE0VvHX4ShAUFdc1ZIdVNlmb2q1Q=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-FJZuWxMfEm2JXto0Uhlls8DNnafiNpS9jclZJJ3n8ns=",
      "url": "_framework/dotnet.native.0jwxfeuctq.js"
    },
    {
      "hash": "sha256-q30iwN6y91qz7TutM3lsDBKLlONch9GpV3JRLEtArcA=",
      "url": "_framework/dotnet.native.9rgixvckz5.wasm"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-kE6r2da20cNCC4yGe5x91dp4bZdGiaY2A/8AiDP/aks=",
      "url": "_framework/netstandard.ouwpswop51.wasm"
    },
    {
      "hash": "sha256-EYu0hLA7keNiJKAQpgzDfBmPaUj5OpsdlnofpF2xzDY=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
