self.assetsManifest = {
  "version": "uXJLMEpf",
  "assets": [
    {
      "hash": "sha256-fe4rznWiEEBlYJsllhJOqLA/ELiLJpqkKPqP3ZfD/s4=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-SqDX9xmrT9BCfPRnqUnprnrwuWL+Hv5YDGl87COYpkg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-QzjV54WPFDZoVGX1oYGL1g4pxgMR0AvEZ5Nfl3uvpOQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-0Vg1f91pA6QEgkLeFyFqoyeO2AdNGpVnLfPmiU/MyHw=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-SB26r6x/mC7LMkYy0aFMUfEMax7kG30HuhKYdlZHOOc=",
      "url": "_framework/CommandLine.o4x8592yhb.wasm"
    },
    {
      "hash": "sha256-Y5RdT2n4ytshh1gt/btSGMzhiYcJRGK3ZF+SRjofokM=",
      "url": "_framework/CsvHelper.z8209o0qpn.wasm"
    },
    {
      "hash": "sha256-JtUQr+j/r+W0PPNkAXPIP5cTIiq1o3s/xlsvPqFhOS0=",
      "url": "_framework/Markdig.695pgtim2t.wasm"
    },
    {
      "hash": "sha256-U2xTR1wv/YhTVQtd1FSuhJLSCKBznBioxTbp9z1z/S8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bmn7pctn57.wasm"
    },
    {
      "hash": "sha256-ZqYbwb+Hs0hOCWNjdJH5rjvkKh8ubPZaZ4Yv1+JqvUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ixbwa60ed8.wasm"
    },
    {
      "hash": "sha256-lzxERXf8iGDUIYT/8zMoyC6hTmSWe6oqkSF4f2YbjYA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5txx2296uk.wasm"
    },
    {
      "hash": "sha256-DbaP6X+TKJcpFClBU0+37TRa/Dzwf6IAi4cu275LG7g=",
      "url": "_framework/Microsoft.AspNetCore.Components.x7nu5k3rb3.wasm"
    },
    {
      "hash": "sha256-La2xU6JjOtZQ3n30oQdcet1PC4W6E6NS44QH4cGtoy4=",
      "url": "_framework/Microsoft.CSharp.52mitgr5ta.wasm"
    },
    {
      "hash": "sha256-C/I92UJ2IWsHi/TDC+Ybt7ysd8x/5GNI+4Pe2MNvftg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.je0s53rda4.wasm"
    },
    {
      "hash": "sha256-D1gFBmB/8RBdSYr4gG7Ed1Z2qLQJS1dlO+ChcE+h5bQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r9vjzw3m36.wasm"
    },
    {
      "hash": "sha256-7j/5TwS1A5vcGXYRrMF+c2+QbQ4fNRbGCUuhe9QNwcQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.u58b67wy0x.wasm"
    },
    {
      "hash": "sha256-3hOonoDTbUF3DETnsp2rbP0tI0O5S6aOCSqdP/2pRwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q1ebwilwsv.wasm"
    },
    {
      "hash": "sha256-Z9OPc8B0gPr7J9dy575WL3owSwn+oRigAg/PJUgLKkc=",
      "url": "_framework/Microsoft.Extensions.Configuration.pslpmrl65x.wasm"
    },
    {
      "hash": "sha256-Kv74crpYX6tgxyS0/h9RSBlB214+156I0hWWFMm/BV0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.m1nixatruw.wasm"
    },
    {
      "hash": "sha256-mnoMkPr8Pok15GyNgDv4d5qvnGuJEAghiIz4Zk20tsA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.yeo0n2g9ok.wasm"
    },
    {
      "hash": "sha256-sVSB5xR7ROxaFMCxaYV6ddotuicTs/oslNvTmjXfFVA=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.9i2s5l4m8k.wasm"
    },
    {
      "hash": "sha256-O0rOdKs0+TZuFOK2biu0fuoO/0vtXx1kJBYAv1ISE+k=",
      "url": "_framework/Microsoft.Extensions.Http.bodsa3a19b.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-GafRn7BYkQeWbqgC9UdhUrETxQXfMBk1hlH2+AefDUc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ln2l8y8n5.wasm"
    },
    {
      "hash": "sha256-sLTzPAxfQuBaABGIMpy5+BzJE820wmb1g7ciiP7HcPw=",
      "url": "_framework/Microsoft.Extensions.Logging.c9ypn9spaw.wasm"
    },
    {
      "hash": "sha256-VUjUGlunFGbXJHOUoTj57wAtiBEgyUoYzAVtMYVP+8A=",
      "url": "_framework/Microsoft.Extensions.Options.79y9245e44.wasm"
    },
    {
      "hash": "sha256-myioBht19J+5++0h/JVb+mYZUgbzi6MQhfO2q/Cj9Qc=",
      "url": "_framework/Microsoft.Extensions.Primitives.11wx31n3r6.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-4jZid7pZynHhV+66ykQHDWk00GPxf4l9zRLERXR/Efc=",
      "url": "_framework/Microsoft.JSInterop.ifnm5tv8of.wasm"
    },
    {
      "hash": "sha256-F35nxzkqR5b5e428rjBwTakgLzduM5Y21B+N65sZ4YA=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.16lf1qqyry.wasm"
    },
    {
      "hash": "sha256-TgY8cmi34RrjI2/5bo4bkrVLoLGY4hKUwsJbGWmam84=",
      "url": "_framework/MtgCsvHelper.ykkmk5io1i.wasm"
    },
    {
      "hash": "sha256-XN2PWRUg4qbp3N+ww/IXuiJY4OQUYFsPKoatXKq0CzU=",
      "url": "_framework/MudBlazor.k0psx1prmx.wasm"
    },
    {
      "hash": "sha256-+2IohdiHD8wJkQ6YK/+b9C6Um33R0NO5V8rYbCHYCdQ=",
      "url": "_framework/ScryfallApi.Client.fn3mbvu0x8.wasm"
    },
    {
      "hash": "sha256-GJHCAMlEtsNMAoiZeu2QuPWYq1OQWwhPgB979kaJN2Y=",
      "url": "_framework/Serilog.Extensions.Logging.khyebs5ndt.wasm"
    },
    {
      "hash": "sha256-TnV0p01o74NQLDdozkQzjRa9Pwv5CLVLKFLyJqNyB7I=",
      "url": "_framework/Serilog.Settings.Configuration.e8mfj5vhcf.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-Wn6jE5pW+l3gOg74zyB6JYfwIt267+6rACdJupCiG5Q=",
      "url": "_framework/Serilog.Sinks.Console.e2loh4s0va.wasm"
    },
    {
      "hash": "sha256-48sj9RF16BdT8tcFXj273uWEViBWnlVgEruwMOJgNts=",
      "url": "_framework/Serilog.Sinks.Debug.rqikcpubbj.wasm"
    },
    {
      "hash": "sha256-LJalPODcYpLUPgb5dGhRKdxz3yqD1TWoULxvieFrY7E=",
      "url": "_framework/Serilog.Sinks.File.kkjb6zkn33.wasm"
    },
    {
      "hash": "sha256-+/3A4lrXGyV1SI30Q8J0ONqqPp8Xhc5WJ4ABmiKHtpQ=",
      "url": "_framework/Serilog.v3jtg2iuay.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-J103R5SguelVnSvCcp/LHR/X+0+bc6S82Oxx9S7EMEM=",
      "url": "_framework/System.Collections.7gu4asju8i.wasm"
    },
    {
      "hash": "sha256-lNF6mDiXY8sOFJN5mK6OfPdNeWBKN5XlbI+XdUawPHA=",
      "url": "_framework/System.Collections.Concurrent.wtuil0vxiy.wasm"
    },
    {
      "hash": "sha256-6fzmvZ86keYsvT1+8UzGhU/tNFRoFsTwjqzDjpyJ7Ik=",
      "url": "_framework/System.Collections.Immutable.1a41lfe2la.wasm"
    },
    {
      "hash": "sha256-BjqDCtJrsZOiOnSJg9fIlUe/iTVuVCGhb3LSonLeXxE=",
      "url": "_framework/System.Collections.NonGeneric.a03rucrpat.wasm"
    },
    {
      "hash": "sha256-tqzRxPPL/HG6pGJxXKwJlDvgVFjt1NzsRZXGDlMa8BU=",
      "url": "_framework/System.Collections.Specialized.u346l1e5zq.wasm"
    },
    {
      "hash": "sha256-wL1nRytJI8tC19/GwuBGz3O5/uOh5RXabg9IOkOcwaM=",
      "url": "_framework/System.ComponentModel.Annotations.ompo2pahs9.wasm"
    },
    {
      "hash": "sha256-2kq23HTfsJtQTy9+WR1qpXVK4U7B8s21fnDnrkbrIss=",
      "url": "_framework/System.ComponentModel.Primitives.ye8xywgz7m.wasm"
    },
    {
      "hash": "sha256-DSGbGaWVio8qDgvgT8ju67eqMtTVLSlrWukwisBBR5c=",
      "url": "_framework/System.ComponentModel.TypeConverter.t8hnqwp8xc.wasm"
    },
    {
      "hash": "sha256-dQLk5B1XqZ9eV5Jpo+uP+1Y2l0UnMPwvonVLdq78/cQ=",
      "url": "_framework/System.ComponentModel.xd8oe19zrb.wasm"
    },
    {
      "hash": "sha256-r8RvvTY7qwHv4Kwdh6j2xwx5vha2X0CRBpwETxc+8s8=",
      "url": "_framework/System.Console.9aqxoosoeq.wasm"
    },
    {
      "hash": "sha256-863U/RHSgOz/wRgX/AbCwiKK/Ag2OhB0JSqytUekXTs=",
      "url": "_framework/System.Data.Common.hfyz12to49.wasm"
    },
    {
      "hash": "sha256-w0aWp6cOtfuQOndUgTEaV/ZmETlNUCVnDZkIsRhuxxQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.lac4mvfswu.wasm"
    },
    {
      "hash": "sha256-WIcRt57jYfZLRdZY8J6gZsDjVtnfXTIpFvuLlmROShg=",
      "url": "_framework/System.Diagnostics.TraceSource.weo394b8e2.wasm"
    },
    {
      "hash": "sha256-YTHHbWgCcVU1y+hawrW/K6aRaDPThDkwKmN+wVMusao=",
      "url": "_framework/System.Drawing.Primitives.pmv5ics9wk.wasm"
    },
    {
      "hash": "sha256-fuFG0ksileDCE3MOsGjhBLpUBviTr3dDPuDfsktoW5c=",
      "url": "_framework/System.Drawing.e50j3te5oy.wasm"
    },
    {
      "hash": "sha256-mStRRwV1wVVf6bUmbgzEf+7gLSIjsgod3yryK+4EKPs=",
      "url": "_framework/System.IO.Compression.lt78iw4525.wasm"
    },
    {
      "hash": "sha256-cco1xeAPVZhQ9HNkfvwlT0+CCl1BEr6F6apxhEpkRf0=",
      "url": "_framework/System.IO.MemoryMappedFiles.h45ikjqq8f.wasm"
    },
    {
      "hash": "sha256-bUtQCqjH9DHNXqtvgt+nHSPyoNoXL64jcAGkerf69N4=",
      "url": "_framework/System.IO.Pipelines.nfee8rup5b.wasm"
    },
    {
      "hash": "sha256-lnvXEkLoAUJxofWdLJQ5FAU3SGRH1l6EiT/jbtb89vo=",
      "url": "_framework/System.Linq.Expressions.64oy5m9g1y.wasm"
    },
    {
      "hash": "sha256-bupWKLPTJwRBIdiDRiWTU5e2dpIWGmGFgNiZrPW93cc=",
      "url": "_framework/System.Linq.qxnhfasr98.wasm"
    },
    {
      "hash": "sha256-6l4Ba4y2hrnPxjGThHLPMb6G6roCZB1zEEdsEyBmZ0E=",
      "url": "_framework/System.Memory.y5s6h3bq2n.wasm"
    },
    {
      "hash": "sha256-m2UcwoYIaEAu1bXmCk+k5sqz6961AyOv1lJQXTUz2fM=",
      "url": "_framework/System.Net.Http.rw4fzblh5a.wasm"
    },
    {
      "hash": "sha256-kEXej7KWzmYaQ6x1jdi8bA0XXmLC8/YrPwHmtflKfnw=",
      "url": "_framework/System.Net.Primitives.4rk2sdk54b.wasm"
    },
    {
      "hash": "sha256-jn6SLQ+Uewu4s+QsL1IHPaUVIrkMvU2uQAQiDvMhICw=",
      "url": "_framework/System.ObjectModel.ulq3cn90zq.wasm"
    },
    {
      "hash": "sha256-m8WstxtoCKJMOm5Z5wo5sz2DYxKXni+rqnPYevu6mIo=",
      "url": "_framework/System.Private.CoreLib.7dkerr28r1.wasm"
    },
    {
      "hash": "sha256-ceJ9LzYXbA2acY765SmYj5M8m6pPkyk21HnjfN9NtrY=",
      "url": "_framework/System.Private.Uri.bh63q8ilq7.wasm"
    },
    {
      "hash": "sha256-IoZaD2ZoXkWZYHKmKRdqPZpsm6Af6PfGyMXGG7DMBik=",
      "url": "_framework/System.Private.Xml.y7cworpu8z.wasm"
    },
    {
      "hash": "sha256-Si+b7AMmIP8AhfMaxJu24RUHDBhROCHgsKoou3dvthE=",
      "url": "_framework/System.Reflection.Metadata.6x2amjgcm5.wasm"
    },
    {
      "hash": "sha256-8rLfGa33AEEcSFwfs53Ed9wufgcoM4hkpzO5ruffP28=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.q2tnoebwh1.wasm"
    },
    {
      "hash": "sha256-x//xU3DJi0E2+wKgW33NmbmW27iQNlteF/foR9IR6RY=",
      "url": "_framework/System.Runtime.InteropServices.ng7gmszazu.wasm"
    },
    {
      "hash": "sha256-Oq1uNiE6OLCCQpPTFltoVV81B9U0K8XeeRxPEd43uH0=",
      "url": "_framework/System.Runtime.Numerics.qrirji0hd2.wasm"
    },
    {
      "hash": "sha256-8mKBoRt6/yJ6Tr+zWyQorwdNvCK7+g/AxMTK91pNKaw=",
      "url": "_framework/System.Runtime.Serialization.Formatters.qip7an6eta.wasm"
    },
    {
      "hash": "sha256-co9UY7KfQGSNaPQYa9jFAu2a1+eyTa//UUVE7IoJOaI=",
      "url": "_framework/System.Runtime.e4vo1rp1ez.wasm"
    },
    {
      "hash": "sha256-SDcoOngTS48eR+nSpsxgCi48svqK/8o8WxbhOzjppOY=",
      "url": "_framework/System.Security.Cryptography.c7cualucks.wasm"
    },
    {
      "hash": "sha256-ltFMk/yJTGbUpMFV1fX+T5ZaWLUXSKiDR9otoHs+45s=",
      "url": "_framework/System.Text.Encoding.Extensions.qgpyxewjbz.wasm"
    },
    {
      "hash": "sha256-1XOnzHzMjd/pxlBbc0vRkHf9rpBoHCLGuyGU2OJ/pKM=",
      "url": "_framework/System.Text.Encodings.Web.rc60gbh5e1.wasm"
    },
    {
      "hash": "sha256-lfp5ZZkIRND5Am43qfDm4T4S9FC5IjwD11zh0aZPyN8=",
      "url": "_framework/System.Text.Json.b45ewxjuz3.wasm"
    },
    {
      "hash": "sha256-1a71xcmW9XEBddYwmes0O1HQ8WfZiOFrmBlUNlLfOyA=",
      "url": "_framework/System.Text.RegularExpressions.xhtq3prs2d.wasm"
    },
    {
      "hash": "sha256-qI7/v4tNXQuXxhEXPHwm0+tCF5DAeURIG8nU/sr9lGE=",
      "url": "_framework/System.Threading.4twtqr4ptx.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-G41jRrFdk4UbBGnLpZwk1GhB97lVCmM0rgThWrmk5ZU=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-2yLCBLbAnPLD0aCNlBTlDGPkOYK2/e56ehGIkYvD3mo=",
      "url": "_framework/dotnet.native.5g2r0emtd8.wasm"
    },
    {
      "hash": "sha256-PHx1SGrP83lRywCNk+A03+3ET+mCFeN2bcA1PELn9G8=",
      "url": "_framework/dotnet.native.olrux5iyh2.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-KOo92OwHN4OkNQ6hcKKHcGeSr0pjbfiDYiyFIlw8970=",
      "url": "_framework/netstandard.02tnnbenks.wasm"
    },
    {
      "hash": "sha256-I1IlUlQX92BvD5ROqmddM5Cb3sPIaLw93OeEaZKd89w=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-YsJTr77VHFWbxjKiYf96yFUuOn16bvhMeXXuUDjjKBw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-pBvPqOZFUueMb1UZvsonHV07Q6nQjX/JbJRLtc49SSs=",
      "url": "data/cards.min.json.gz"
    },
    {
      "hash": "sha256-TH2IRIdNiAXwDhjmmDaJF61/qtfMvNSQ1TEmJudSjgM=",
      "url": "favicon.svg"
    },
    {
      "hash": "sha256-PcTHd6e7hpw7R2ICEwue6d89J6Pbsa5s6hOo0iLYGyc=",
      "url": "icon.svg"
    },
    {
      "hash": "sha256-WmgxpSdy7voglCI8YTqC3e1Ald9Krnu2qgq695AHerg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-PxWw+ZOupQ6f7Awm7xdg1Vydwc9qhmSeoQtCkAyOJ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
