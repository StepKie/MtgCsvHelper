self.assetsManifest = {
  "version": "JUpMmews",
  "assets": [
    {
      "hash": "sha256-I3TVsQDb/Rog9PzU/fWo/rqhOQVsDyyBMZ8jzXnEjN0=",
      "url": "MtgCsvHelper.BlazorWebAssembly.styles.css"
    },
    {
      "hash": "sha256-UfzIMtuUX1gU81Ha1WxwWXPyBbKEDtCT3CPkMKsnreQ=",
      "url": "_framework/CommandLine.patchfha6i.wasm"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-XrsZGktyAakARIo+IPOpkBODiKrhtyzTXNj2m8vj390=",
      "url": "_framework/Markdig.ato3fn3juu.wasm"
    },
    {
      "hash": "sha256-R3UyacfTB9T1xMHMIHVMMZI0RiaKB+4Ybg+j78m5Od4=",
      "url": "_framework/Microsoft.AspNetCore.Components.558eawuvxg.wasm"
    },
    {
      "hash": "sha256-bzs20GQ9q1Ifq0rmIahA3/p1rQM4SD/GV2ySfXZ7pCA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.jn6n69jo4d.wasm"
    },
    {
      "hash": "sha256-b7XFpEBpgrlbVV9emo4iQImzxH/zxafHhv2x1xc4LiA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7ym1nl260l.wasm"
    },
    {
      "hash": "sha256-fc/qVOlrICIbSyE3pjEsjaN6IxnleVzsdU4u2yst6Pc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xbtgn06cw3.wasm"
    },
    {
      "hash": "sha256-APRVYELLPdJUumae8xRAcY16W+fr7NKhRTGxuuz3FGw=",
      "url": "_framework/Microsoft.CSharp.8ekzqqiuba.wasm"
    },
    {
      "hash": "sha256-7BVGRhcVU4GB7OIz3iFUJ17OLSftAPZRZqLlfn9yMgA=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.8z6j4nkfuo.wasm"
    },
    {
      "hash": "sha256-1P+Zzl5D59KCH78flC4xITlVepQnZuZiSjNT64AruT0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.cwiycgimzh.wasm"
    },
    {
      "hash": "sha256-3gIRrSzp0H204Hux3PlvPIqChIrQWmh8qgfmerVuoXg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.6bhyx4eloy.wasm"
    },
    {
      "hash": "sha256-77Fnv68niEQGAt6FyYAD3YZ6oXOMn78t5VIl/cTWYBE=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.fcfhmtqd20.wasm"
    },
    {
      "hash": "sha256-aNjmAynmBFhQ7fUCsY+hf44Vmljlew/1O1s8Gv1ys9o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ogdd3gf9kw.wasm"
    },
    {
      "hash": "sha256-bQUv7kGhgDTmCIX9C1CwyDKH2/EflEg/YlSw0PkWHvE=",
      "url": "_framework/Microsoft.Extensions.Configuration.vxt8lztxtd.wasm"
    },
    {
      "hash": "sha256-Fyomf+MvKU+U0UJocL/QqQOa2hBFqGUTFR7ys7Qp5Oo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.94tiam18tx.wasm"
    },
    {
      "hash": "sha256-ViXZWP20lik6jz4YKNy9sGC9LVA+oVpRMqJ5eDc3saI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i12kadk469.wasm"
    },
    {
      "hash": "sha256-Y50HX3PQMJ4soEY3qF5l62/MIU7ySWSua6rOnJTS588=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.v9g0nhfssu.wasm"
    },
    {
      "hash": "sha256-ZHOdqgOueW9YoTx9IkCoa6+U4icIqB0V+w3S+jCI5xE=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.sa27s8rs4b.wasm"
    },
    {
      "hash": "sha256-u6WF/yNunpz7DfMc+hZBx/c2z54jJ+DLP9R9X7LHGHo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.931rgf7ct7.wasm"
    },
    {
      "hash": "sha256-bkkw3ba1G6KYCU63h/CnW9ZLcXk6DWvuucuT4VtMymI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.63qufu34wl.wasm"
    },
    {
      "hash": "sha256-mSTkUwaJW1rzV8XnxyTe2sR0d+be7DjzHDESqhb0y0I=",
      "url": "_framework/Microsoft.Extensions.Http.bvoe29ity8.wasm"
    },
    {
      "hash": "sha256-7he0KJcv7cGdqYeyRiqk2HHCpfbgPwMraaI+2uRi6ho=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.aed1u0pqfk.wasm"
    },
    {
      "hash": "sha256-C5hyh/s8qtXNfihhmY6W7WTXI0Eddvv1EbD7wB0zGNY=",
      "url": "_framework/Microsoft.Extensions.Logging.dageq1qagu.wasm"
    },
    {
      "hash": "sha256-TuHBVLLhoCufNP8rpAsJnV9JAn2Tk2glP3Ut2lrMvTM=",
      "url": "_framework/Microsoft.Extensions.Options.u9tmlj4p1y.wasm"
    },
    {
      "hash": "sha256-TKORY8CCoM+5MPgQyw9N1LGPA1oB5ItogkxMhUcNRlw=",
      "url": "_framework/Microsoft.Extensions.Primitives.cu7wxzg51n.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-OArFp/X9PJG6WAqU9vxfCRBMlTJyRmWkyBp7afAVD3Q=",
      "url": "_framework/Microsoft.JSInterop.kxhgfet8bu.wasm"
    },
    {
      "hash": "sha256-/oxYoOxxL9V5xBeW8sGkbGeS2pZpo35FCUTTuQm7xxs=",
      "url": "_framework/MtgCsvHelper.BlazorWebAssembly.mu32luq45q.wasm"
    },
    {
      "hash": "sha256-7eZYo+yvYZ8Kix+j+uQ3Qx/EgL6bwAOfwRCHU5rBzWc=",
      "url": "_framework/MtgCsvHelper.luufd8lcs2.wasm"
    },
    {
      "hash": "sha256-nmclXK1Xpnx23mVNIppdw7OyofbeuoobudBtF49jrZs=",
      "url": "_framework/ScryfallApi.Client.2fsn0ugldn.wasm"
    },
    {
      "hash": "sha256-7Ph4DpIYUm6II3daX+GzmBUn++wgpMabIVkhba2X9FE=",
      "url": "_framework/Serilog.4s67d7c21i.wasm"
    },
    {
      "hash": "sha256-y4W0voy68MdBaTWWr+aKh2gJwf1766giLjnw5DdKsmY=",
      "url": "_framework/Serilog.Extensions.Logging.3ys5876a4v.wasm"
    },
    {
      "hash": "sha256-F3KAlF5HjvkTXwbLVn9fiSxSPwdZrsU3wEdEI3nsBo4=",
      "url": "_framework/Serilog.Settings.Configuration.vqprv27ecs.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-OEANd7H/LtEUuu/2wVTnwdZYptIQAM/dOxu0sU707Z8=",
      "url": "_framework/Serilog.Sinks.Debug.wm4zeothzh.wasm"
    },
    {
      "hash": "sha256-KvMWoiK6uwOzjc9HiRXtCYQvPVG8xOQPK8OLvVqRMq4=",
      "url": "_framework/Serilog.Sinks.File.2xjoy8x0ef.wasm"
    },
    {
      "hash": "sha256-c5jjkd5Egevig1da+dyQDYfATbKFpcPlUU6NGAK6ps0=",
      "url": "_framework/System.Collections.9tn46o3388.wasm"
    },
    {
      "hash": "sha256-YJIaXtTw+mxX8mBDonTaTalDpu2Sp6wGdVyNYJBlW9g=",
      "url": "_framework/System.Collections.Concurrent.w8quikdvtq.wasm"
    },
    {
      "hash": "sha256-ekWVo/zQ68MPGJPov69vdLA507LsPuBtpFg1pxTSWkY=",
      "url": "_framework/System.Collections.Immutable.mttenwgj16.wasm"
    },
    {
      "hash": "sha256-BMeGiwxc0jU1+Nk4iWlpES0Xwa62TyjTqFXArJiyAwk=",
      "url": "_framework/System.Collections.NonGeneric.w9yytim7ge.wasm"
    },
    {
      "hash": "sha256-B5WlUd+4x8KMiHRjXInp7XVzNQVBM9iCnpgqew/K0RI=",
      "url": "_framework/System.Collections.Specialized.ld53l2vv8d.wasm"
    },
    {
      "hash": "sha256-2wJbBJ+uQvKsQbS5UUAvAtDtJr8SqMmWDAw+CsAPw98=",
      "url": "_framework/System.ComponentModel.9jbfhdd9o4.wasm"
    },
    {
      "hash": "sha256-aClr6pPyMEZerw4/IzKrNRCZEuAn4GDjN2cv8apy4Lw=",
      "url": "_framework/System.ComponentModel.Primitives.sv7ylajgwz.wasm"
    },
    {
      "hash": "sha256-AgQ56lefpdz8kNjuiFrV+Mc6VRucNV85PAiSf4JD4oU=",
      "url": "_framework/System.ComponentModel.TypeConverter.ugu3z7cgcx.wasm"
    },
    {
      "hash": "sha256-iXYDc20LWdm6ELD2BNk9RNE5s9oHmV/JEAkeZkYrBiA=",
      "url": "_framework/System.Console.3dacagorzn.wasm"
    },
    {
      "hash": "sha256-D+NjEELv2Jl5AlYQ7n5QcZ2D6120PNecbcb2nJFI1Ac=",
      "url": "_framework/System.Data.Common.fcx96rgre9.wasm"
    },
    {
      "hash": "sha256-BtCM597xm+k8u9hCVO07F9O+/8yA7wJ2xQdA8+8pcw4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.29wvvz3k9h.wasm"
    },
    {
      "hash": "sha256-yvc4p/bOpGvHZrYLpsKLLmiBeXNqZ6x4v3m1GiWpuHk=",
      "url": "_framework/System.Diagnostics.TraceSource.6cgm46rgip.wasm"
    },
    {
      "hash": "sha256-bzXJoRVcRnyoxOCSMreix72mWvcA5CAA0Cl7Rd89ruM=",
      "url": "_framework/System.Drawing.5ziebqy3j0.wasm"
    },
    {
      "hash": "sha256-lqyZ72qhFrUryPd96z26GGtM3p3uH89cwmGxHKrPKbE=",
      "url": "_framework/System.Drawing.Primitives.um68xmouvq.wasm"
    },
    {
      "hash": "sha256-uZRdUiPX1T73lpoBvi1H8GSuNNZr4BiABWzb0pvQ6cM=",
      "url": "_framework/System.IO.FileSystem.Watcher.bjxmcvzq34.wasm"
    },
    {
      "hash": "sha256-f/yygliqxDUVbK9P7/AvFVUPipAv34X76QkaPC61T6I=",
      "url": "_framework/System.IO.MemoryMappedFiles.rlfuqyvxkv.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-PG8ywou355hx2UobeOk7c7qi3eOvJqbJJzjU16hBShc=",
      "url": "_framework/System.Linq.Expressions.o9e8daa5nk.wasm"
    },
    {
      "hash": "sha256-jNS5kUI4OCyA/Ndg04arxwBLB8sbbKqLP/N6MQMFoLc=",
      "url": "_framework/System.Linq.sqjqt6zwhd.wasm"
    },
    {
      "hash": "sha256-1aQtWAsFOnyv0iSp8sXIozV5TRVWg7q+Y2v5463QOak=",
      "url": "_framework/System.Memory.3q0uc4e4j8.wasm"
    },
    {
      "hash": "sha256-oRPmMG+nJQPD6yLfoJTdovGFVaMYFD9IoL3Cno+2DDk=",
      "url": "_framework/System.Net.Http.btglsex0vq.wasm"
    },
    {
      "hash": "sha256-/FmecRu5Wfb7p4wjY3KDbGzMWRfNbwsnnAnzdbPF9b8=",
      "url": "_framework/System.Net.Primitives.gd20ym2wiq.wasm"
    },
    {
      "hash": "sha256-vkgQoE8aw3kMr99xV0JjKiQdQFDEDbIOBUFtOjQ/RHg=",
      "url": "_framework/System.ObjectModel.maobltv5jf.wasm"
    },
    {
      "hash": "sha256-GZKqG2Rg8NeBEp72lsZ0y+kh0o9Na7RBtH439aMBohY=",
      "url": "_framework/System.Private.CoreLib.ng51033y7n.wasm"
    },
    {
      "hash": "sha256-6NgwcHdFRHIfch0ZjkN9ESIBhvQHWVw7GXAWMnWRmNY=",
      "url": "_framework/System.Private.Uri.4hsfn9e604.wasm"
    },
    {
      "hash": "sha256-GPK/+s2V3VEr+19My6Dh3PTbbZYQVMy3miQ/iuDqTBo=",
      "url": "_framework/System.Private.Xml.wugb0mnxh7.wasm"
    },
    {
      "hash": "sha256-gih1y3KTcIqYl1LL5mKim+C+icZyqqOCwFWAUDhdL08=",
      "url": "_framework/System.Reflection.Metadata.uga6la8hv2.wasm"
    },
    {
      "hash": "sha256-8v7jVijrzRlaTmvdds4+ZNyPL5DYfnYnzFYT2HtkqwM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u9tzo6t7zm.wasm"
    },
    {
      "hash": "sha256-xbaenb4iwzQANJLwYU9qoLTSv6HDsQDdrqIQaqq42pw=",
      "url": "_framework/System.Runtime.InteropServices.pry7fjve8v.wasm"
    },
    {
      "hash": "sha256-oNKKZmjCO5i8uJ+BDolFk/N48n9UbsVduxjsWaDPGDc=",
      "url": "_framework/System.Runtime.Numerics.8ajjl09647.wasm"
    },
    {
      "hash": "sha256-a0JAY5+9fTuPHgSDBQHtDqniyt7l9M2eaR07qWglzyA=",
      "url": "_framework/System.Runtime.Serialization.Formatters.1p96fuurrj.wasm"
    },
    {
      "hash": "sha256-4av7FPnozHHSXZ/NOWa+QVjZq9gokeCpvTOk1T5i96c=",
      "url": "_framework/System.Runtime.Serialization.Primitives.3zvl3n6b03.wasm"
    },
    {
      "hash": "sha256-H8J1Lt7Xq5Ycr09oQ8sBBeLj/kApFwLJUhZcChdUMPU=",
      "url": "_framework/System.Runtime.jfzz4c379f.wasm"
    },
    {
      "hash": "sha256-nsEfRZ/GbKNFez3rdTFS9SH24qbN7tAj6NnPzFpX7uM=",
      "url": "_framework/System.Security.Cryptography.qdnpjzel8r.wasm"
    },
    {
      "hash": "sha256-F2EnIoFynO9FTiVa0TLwVvbJ9bn+a4MGhRQpzzxOOSs=",
      "url": "_framework/System.Text.Encoding.Extensions.r3tvss3oy9.wasm"
    },
    {
      "hash": "sha256-oAvGjE7zOfELanuhXBazvipywX/fnbrfBmWPDH/R3bw=",
      "url": "_framework/System.Text.Encodings.Web.8qvkegu1ci.wasm"
    },
    {
      "hash": "sha256-lby+WiDZzjES0BEGyZOFyVI1D8tDYilzsMmEqstz4sM=",
      "url": "_framework/System.Text.Json.5o30u3uoon.wasm"
    },
    {
      "hash": "sha256-nEjK/hAE5QFngm/LKxQe4UrTpun0INSL5jFvIReQ5v0=",
      "url": "_framework/System.Text.RegularExpressions.85u4jtx96h.wasm"
    },
    {
      "hash": "sha256-XHQ9m9D7mYA8FhB2hQiTxWYNTaivTn8T6F8w2jruGzc=",
      "url": "_framework/System.Threading.olh5kijxhx.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-I7tGXeVBF9fRFABqtK2AEXenM4OBeWLufUrx/6P/2Xo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-4vq5CQ7v9diwWvPHXK/GhIDl7zC3FT48gy7hU8zvRbM=",
      "url": "_framework/netstandard.yv2uvjvsy6.wasm"
    },
    {
      "hash": "sha256-EYu0hLA7keNiJKAQpgzDfBmPaUj5OpsdlnofpF2xzDY=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-AF9wlJkHXH/bIWwIBIiR7Dn6jtK5aVyigSlW6PIH+1g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-uijWoCuPL1NdC3qX8SyrwrR+ugbfQuFhXG4PX1sw6Sg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-v9sGWYWxFwReO3hbAJGPz0ugp2E5EP1IDvLFQzzBO84=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
